# 📈 High-Performance Stock Matching Engine

<div align="center">

[![Java Version](https://img.shields.io/badge/Java-17%2B-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)](https://openjdk.org/)
[![Build Tool](https://img.shields.io/badge/Maven-3.8%2B-C71A36?style=for-the-badge&logo=apachemaven&logoColor=white)](https://maven.apache.org/)
[![Database](https://img.shields.io/badge/SQLite-3-003B57?style=for-the-badge&logo=sqlite&logoColor=white)](https://www.sqlite.org/)
[![Testing](https://img.shields.io/badge/JUnit-5%20(54%20Tests%20Passing)-25A162?style=for-the-badge&logo=junit5&logoColor=white)](https://junit.org/junit5/)
[![Concurrency](https://img.shields.io/badge/Concurrency-Thread--Safe%20Queue-blue?style=for-the-badge&logo=speedtest&logoColor=white)](#concurrency--threading-architecture)
[![Algorithm](https://img.shields.io/badge/Matching-Price--Time%20Priority%20(FIFO)-8A2BE2?style=for-the-badge)](#matching-algorithm--order-lifecycle)
[![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)](LICENSE)

<p align="center">
  <strong>A multi-threaded, low-latency in-memory stock order matching engine simulator built in Java 17.</strong><br>
  Implements Price-Time Priority (FIFO) matching, Market & Limit order execution, dual red-black tree order books, ACID SQLite persistence, asynchronous order queues, and real-time financial reporting.
</p>

[Key Features](#-key-features) •
[System Architecture](#-system-architecture) •
[Order Matching Mechanics](#-matching-algorithm--order-lifecycle) •
[Database Schema](#-database-schema) •
[Quick Start](#-quick-start) •
[CLI Showcase](#-interactive-cli-showcase) •
[Project Structure](#-project-structure) •
[Testing](#-testing--verification)

---

</div>

## 🌟 Key Features

- **⚡ In-Memory Dual-Tree Order Book**
  - Uses `TreeMap` for price levels: descending for **Bids** (highest price priority) and ascending for **Asks** (lowest price priority).
  - Maintains a FIFO `LinkedList` per price level to guarantee deterministic **Time Priority** ($O(1)$ queue operations).
- **🧵 Asynchronous Single-Writer Concurrency Model**
  - Producer-consumer architecture powered by `LinkedBlockingQueue`.
  - Multiple client/trader threads can submit orders simultaneously without locking or blocking the matching engine.
  - Dedicated background matching worker eliminates lock contention on order books.
- **🔄 Versatile Order Types & Partial Fills**
  - **Limit Orders**: Matches at resting book price or better; unexecuted quantity rests in the order book.
  - **Market Orders**: Aggressively sweeps available resting liquidity at best market prices.
  - Full support for multi-fill executions and order status tracking (`NEW`, `PARTIALLY_FILLED`, `FILLED`, `CANCELLED`).
- **💾 ACID SQLite Persistence & Audit Trail**
  - Embedded SQLite database (`stock_engine.db`) initialized via automatic SQL DDL migration.
  - Transactional persistence of orders, executed trades, and complete chronological event auditing (`audit_log`).
- **📁 Robust CSV Bulk Ingestion**
  - Ingests high-volume order batches from CSV files (`data/orders.csv`).
  - Resilient parser with line-by-line validation, graceful error isolation, and detailed syntax error reporting.
- **📊 Financial Analytics & EOD Reporting**
  - Real-time Volume-Weighted Average Price (**VWAP**) computation.
  - Top traded symbols by volume leaderboard.
  - Comprehensive End-of-Day (**EOD**) summary reports with formatted terminal display and file export capabilities.

---

## 🏛 System Architecture

The engine uses a decoupled, event-driven pipeline inspired by the LMAX Disruptor / Single-Writer pattern to guarantee high throughput and deterministic order matching.

```
+-----------------------------------------------------------------------------------+
|                                 CLIENT INGESTION                                  |
|   +-----------------------+     +-----------------------+     +-----------------+ |
|   |   Interactive CLI     |     |   CSV Batch Parser    |     |  Trader Threads | |
|   +-----------+-----------+     +-----------+-----------+     +--------+--------+ |
+---------------|-----------------------------|--------------------------|----------+
                |                             |                          |
                +----------------------+      |      +-------------------+
                                       |      |      |
                                       v      v      v
                           +-------------------------------+
                           |     OrderService.submit()     |
                           |   Validation & Verification   |
                           +---------------+---------------+
                                           |
                                           v
                       +---------------------------------------+
                       |      Thread-Safe BlockingQueue        |
                       |    LinkedBlockingQueue<Order>         |
                       +-------------------+-------------------+
                                           |
                                           v
                    +----------------------------------------------+
                    |        MatchingEngine Worker Thread          |
                    |          Single-Writer Event Loop            |
                    +----------------------+-----------------------+
                                           |
                    +----------------------+-----------------------+
                    |                                              |
                    v                                              v
      +----------------------------+                +------------------------------+
      |  OrderBook (Per Symbol)    |                |   Persistence Layer (DAO)    |
      |                            |  Generates     |                              |
      |  BIDS: TreeMap (Desc)      | ------------>  |  OrderDao  -> SQLite orders  |
      |  ASKS: TreeMap (Asc)       |     Trades     |  TradeDao  -> SQLite trades  |
      |  Level: FIFO Queue (Order) |                |  AuditLog  -> SQLite audit   |
      +----------------------------+                +------------------------------+
                                                                   |
                                                                   v
                                                    +------------------------------+
                                                    |        ReportService         |
                                                    |  VWAP, Most Active, EOD Logs |
                                                    +------------------------------+
```

### Flow Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Trader as Trader / CLI / CSV
    participant Svc as OrderService
    participant Q as BlockingQueue<Order>
    participant Eng as MatchingEngine Worker
    participant Book as OrderBook (Symbol)
    participant DB as SQLite DB (Order/Trade DAO)

    Trader->>Svc: submitLimitOrder() / submitMarketOrder()
    Svc->>Q: offer(order) [Thread-Safe, Non-Blocking]
    loop Single-Writer Event Loop
        Eng->>Q: take() / poll()
        Eng->>Book: match(order)
        alt Opposite book has matchable liquidity
            Book-->>Eng: List<Trade> generated
            Eng->>DB: saveTrades(List<Trade>)
            Eng->>DB: updateOrderStatus(FILLED / PARTIALLY_FILLED)
        end
        alt Remaining quantity on Limit Order
            Eng->>Book: addOrder(order) [Rests in book]
        end
    end
```

---

## 🎯 Matching Algorithm & Order Lifecycle

### Price-Time Priority (FIFO) Rule

1. **Price Priority**:
   - For Buy Orders (**Bids**): Highest price has highest priority.
   - For Sell Orders (**Asks**): Lowest price has lowest priority.
2. **Time Priority**:
   - If multiple orders exist at the identical price point, the order submitted first is executed first.
3. **Execution Price**:
   - The trade price is always set by the **resting order** already sitting in the order book.

### Example Walkthrough

| Action | Order Details | Resulting Book State | Trade Executed |
|:---|:---|:---|:---|
| **1. Sell Limit** | `100 AAPL @ $150.00` | Asks: `[$150.00: 100]` | None (Resting Ask) |
| **2. Sell Limit** | `50 AAPL @ $150.00` | Asks: `[$150.00: 100, 50]` (FIFO queue) | None (Resting Ask) |
| **3. Buy Limit** | `120 AAPL @ $150.00` | Matches `100` from 1st ask, `20` from 2nd ask | `100 AAPL @ $150.00` <br> `20 AAPL @ $150.00` |
| **Book Balance** | Remaining: `30 AAPL @ $150.00` | Asks: `[$150.00: 30]` | Order #3 is `FILLED`, Order #2 is `PARTIALLY_FILLED` |

### Order State Machine

```
              +----------------------+
              |         NEW          |
              +-----------+----------+
                          |
              +-----------+-----------+
              |                       |
              v                       v
    +-------------------+   +--------------------+
    | PARTIALLY_FILLED  |   |       FILLED       |
    +---------+---------+   +--------------------+
              |
              v
    +-------------------+
    |      FILLED       |
    +-------------------+
```

---

## 🗄 Database Schema

The application automatically provisions an ACID-compliant SQLite relational database (`stock_engine.db`) using `schema.sql`:

```sql
-- Orders Table
CREATE TABLE IF NOT EXISTS orders (
    order_id    TEXT PRIMARY KEY,
    symbol      TEXT    NOT NULL,
    side        TEXT    NOT NULL CHECK (side IN ('BUY', 'SELL')),
    order_type  TEXT    NOT NULL CHECK (order_type IN ('MARKET', 'LIMIT')),
    price       REAL,                       -- NULL for market orders
    quantity    INTEGER NOT NULL CHECK (quantity > 0),
    filled_qty  INTEGER NOT NULL DEFAULT 0,
    status      TEXT    NOT NULL DEFAULT 'NEW'
                        CHECK (status IN ('NEW', 'PARTIALLY_FILLED', 'FILLED', 'CANCELLED')),
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Trades Table
CREATE TABLE IF NOT EXISTS trades (
    trade_id        TEXT PRIMARY KEY,
    buy_order_id    TEXT NOT NULL REFERENCES orders(order_id),
    sell_order_id   TEXT NOT NULL REFERENCES orders(order_id),
    symbol          TEXT NOT NULL,
    price           REAL NOT NULL,
    quantity        INTEGER NOT NULL CHECK (quantity > 0),
    executed_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Audit Log Table
CREATE TABLE IF NOT EXISTS audit_log (
    log_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type   TEXT NOT NULL,
    reference_id TEXT,
    details      TEXT,
    logged_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Indices for Low-Latency Lookups
CREATE INDEX IF NOT EXISTS idx_orders_symbol ON orders(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_audit_event   ON audit_log(event_type);
```

---

## 📂 Project Structure

```text
stock-matching-engine/
│
├── .gitignore                         # Strict repository gitignore
├── pom.xml                            # Maven build descriptor (Java 17, SQLite, JUnit 5)
├── README.md                          # Visual documentation & architecture
│
├── data/
│   └── orders.csv                     # Sample bulk order input dataset
│
├── src/
│   ├── main/
│   │   ├── java/com/matchingengine/
│   │   │   ├── Main.java              # Interactive CLI entrypoint & lifecycle
│   │   │   │
│   │   │   ├── book/
│   │   │   │   └── OrderBook.java     # Dual TreeMap + FIFO Queue order book
│   │   │   │
│   │   │   ├── engine/
│   │   │   │   └── MatchingEngine.java# Multi-threaded worker event loop & queue
│   │   │   │
│   │   │   ├── model/
│   │   │   │   ├── Order.java         # Base order model
│   │   │   │   ├── LimitOrder.java    # Limit order specification
│   │   │   │   ├── MarketOrder.java   # Market order specification
│   │   │   │   ├── OrderSide.java     # BUY / SELL enum
│   │   │   │   ├── OrderStatus.java   # NEW, PARTIALLY_FILLED, FILLED, CANCELLED
│   │   │   │   └── Trade.java         # Executed trade representation
│   │   │   │
│   │   │   ├── dao/
│   │   │   │   ├── OrderDao.java      # JDBC data access for orders
│   │   │   │   └── TradeDao.java      # JDBC data access for trades & audit_log
│   │   │   │
│   │   │   ├── service/
│   │   │   │   ├── OrderService.java  # Order submission & orchestration
│   │   │   │   └── ReportService.java # VWAP, volume ranking, EOD reports
│   │   │   │
│   │   │   ├── util/
│   │   │   │   ├── AppLogger.java     # Lightweight timestamped logging framework
│   │   │   │   └── CsvOrderParser.java# CSV parser with syntax validation
│   │   │   │
│   │   │   └── exception/
│   │   │       ├── InvalidOrderException.java
│   │   │       └── OrderBookException.java
│   │   │
│   │   └── resources/
│   │       └── schema.sql             # Relational DDL schema & indices
│   │
│   └── test/java/com/matchingengine/
│       ├── book/OrderBookTest.java    # Unit tests for FIFO priority & matching
│       ├── dao/DaoTest.java           # SQLite transactional CRUD tests
│       ├── engine/
│       │   ├── MatchingEngineTest.java# Order lifecycle & queue tests
│       │   └── ConcurrencyTest.java   # High-concurrency multi-threaded stress tests
│       ├── model/OrderTest.java       # Domain model integrity tests
│       ├── service/ServiceTest.java   # Service orchestration & VWAP math tests
│       └── util/UtilTest.java         # Parser resilience & logging tests
```

---

## 🚀 Quick Start

### Prerequisites

- **Java Development Kit (JDK)**: 17 or higher (`java -version`)
- **Apache Maven**: 3.8 or higher (`mvn -version`)
- **Git**: (`git --version`)

### 1. Build the Application

Clone the repository and compile the project using Maven:

```bash
cd stock-matching-engine
mvn clean package
```

The build compiles the source code, runs all 54 test suites, and bundles dependencies into an executable shaded JAR at `target/stock-matching-engine-1.0-SNAPSHOT.jar`.

### 2. Run the Interactive CLI

Launch the executable JAR directly:

```bash
java -jar target/stock-matching-engine-1.0-SNAPSHOT.jar
```

*Or run directly via Maven:*

```bash
mvn exec:java -Dexec.mainClass="com.matchingengine.Main"
```

---

## 🖥 Interactive CLI Showcase

### Main Menu Interface

```text
+======================================+
|     Stock Matching Engine - Menu     |
+======================================+
|  1. Submit Order                     |
|  2. View Order Book                  |
|  3. Import Orders from CSV           |
|  4. Run Report (VWAP / Most Active)  |
|  5. Exit                             |
+======================================+
Select option:
```

---

### 1. Submitting Orders

Supports both **LIMIT** and **MARKET** orders:

```text
--- Submit New Order ---
Enter Stock Symbol (e.g. AAPL, TSLA): AAPL
Side (1 = BUY, 2 = SELL, or BUY/SELL): 1
Order Type (1 = LIMIT, 2 = MARKET, or LIMIT/MARKET): 1
Quantity (positive integer): 150
Limit Price ($): 182.50
Successfully submitted LIMIT order: BUY 150 AAPL @ $182.50
```

---

### 2. Formatted Level 2 Depth Order Book

View live resting liquidity organized by price levels and time priority:

```text
================== ORDER BOOK: AAPL ==================
Best Bid: $182.50 | Best Ask: $183.10 | Total Resting Orders: 4

--- ASKS (SELLERS) [Lowest ask first] ---
Price        | Qty        | Orders  
--------------------------------------
$183.10      | 200        | 1       
$183.50      | 500        | 2       

--- BIDS (BUYERS) [Highest bid first] ---
Price        | Qty        | Orders  
--------------------------------------
$182.50      | 150        | 1       
$181.00      | 300        | 1       
====================================================
```

---

### 3. Bulk CSV Ingestion

Easily import hundreds of orders from CSV format with instantaneous validation:

```text
--- Import Orders from CSV ---
Enter CSV file path (press Enter for default 'data/orders.csv'): 

Import Result for 'data/orders.csv':
  Valid orders parsed: 8
  Malformed lines:     3

Errors encountered:
  [!] Line 5: Invalid price format 'not_a_price'
  [!] Line 8: Quantity must be positive, found '-10'
  [!] Line 11: Missing price for LIMIT order

Submitted 8 orders into the matching engine.
```

#### CSV Format Specification (`data/orders.csv`)

```csv
orderId,symbol,side,type,price,quantity
ORD001,AAPL,BUY,LIMIT,150.25,100
ORD002,GOOG,SELL,LIMIT,2800.00,50
ORD003,MSFT,BUY,MARKET,,200
ORD005,AMZN,SELL,LIMIT,3400.50,30
ORD006,META,BUY,MARKET,,150
ORD008,NVDA,BUY,LIMIT,220.75,80
ORD009,AAPL,SELL,MARKET,,120
```

---

### 4. Financial Reports & EOD Analytics

Generate real-time Volume-Weighted Average Price (**VWAP**), trading activity leaderboards, or export end-of-day summaries:

```text
====================================================
         STOCK MATCHING ENGINE - EOD REPORT         
====================================================
Total Trades: 14
Total Volume: 3,450 shares
Total Value:  $582,190.50

--- Most Active Symbols ---
  #1 AAPL   : 1,800 shares traded
  #2 MSFT   : 1,150 shares traded
  #3 NVDA   : 500 shares traded
====================================================
```

---

## 🧪 Testing & Verification

The test suite covers unit logic, database transactions, order parsing, service math, and multi-threaded race conditions:

```bash
cd stock-matching-engine
mvn test
```

### Test Summary

| Test Suite | Coverage Area | Tests Run | Result |
|:---|:---|:---:|:---:|
| `OrderBookTest` | Price-Time priority matching, partial fills, book depth | 10 | ✅ PASS |
| `DaoTest` | SQLite order/trade persistence, ACID transaction rollbacks | 8 | ✅ PASS |
| `ConcurrencyTest` | Multi-threaded simultaneous order submissions & race-freedom | 1 | ✅ PASS |
| `MatchingEngineTest` | Queue draining, worker lifecycle, dispatching | 6 | ✅ PASS |
| `ServiceTest` | OrderService submission, VWAP calculation math, EOD reports | 11 | ✅ PASS |
| `OrderTest` | Domain model validations, fill arithmetic, immutability | 7 | ✅ PASS |
| `UtilTest` | CsvOrderParser error resilience, AppLogger formatting | 6 | ✅ PASS |
| `ExceptionTest` | Custom exception hierarchy & error handling | 5 | ✅ PASS |
| **Total** | **Full System Test Suite** | **54** | **100% PASS** |

---

## ⚙ Concurrency & Threading Architecture

- **Thread Concurrency**: Producer threads submit orders using `BlockingQueue.offer()` ($O(1)$ lock-free non-blocking operation).
- **Zero Book Contention**: A single dedicated worker thread executes `take()` from the queue and updates the `OrderBook` in sequence, completely avoiding multi-threaded lock contention and deadlocks on the in-memory order book.
- **Concurrent Symbol Partitioning**: Symbols are partitioned in a `ConcurrentHashMap<String, OrderBook>`, allowing easy scale-out to per-symbol worker threads if needed.

---

## 📄 License

Distributed under the [MIT License](LICENSE). Free for academic, personal, and commercial use.
