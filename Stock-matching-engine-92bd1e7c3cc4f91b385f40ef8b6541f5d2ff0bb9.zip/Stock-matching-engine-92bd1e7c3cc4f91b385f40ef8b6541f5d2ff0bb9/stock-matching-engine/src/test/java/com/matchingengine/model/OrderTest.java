package com.matchingengine.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for Order, MarketOrder, LimitOrder, and Trade model classes.
 */
class OrderTest {

    @Test
    void testMarketOrderCreation() {
        MarketOrder order = new MarketOrder("AAPL", OrderSide.BUY, 100);
        assertNotNull(order.getOrderId());
        assertEquals("AAPL", order.getSymbol());
        assertEquals(OrderSide.BUY, order.getSide());
        assertEquals(100, order.getQuantity());
        assertEquals(0, order.getFilledQuantity());
        assertEquals(100, order.getRemainingQuantity());
        assertEquals(0.0, order.getPrice());
        assertEquals(OrderStatus.NEW, order.getStatus());
        assertNotNull(order.getCreatedAt());
    }

    @Test
    void testLimitOrderCreation() {
        LimitOrder order = new LimitOrder("TSLA", OrderSide.SELL, 50, 250.75);
        assertNotNull(order.getOrderId());
        assertEquals("TSLA", order.getSymbol());
        assertEquals(OrderSide.SELL, order.getSide());
        assertEquals(50, order.getQuantity());
        assertEquals(250.75, order.getPrice(), 0.001);
        assertEquals(OrderStatus.NEW, order.getStatus());
    }

    @Test
    void testOrderIsLimitOrder() {
        MarketOrder market = new MarketOrder("MSFT", OrderSide.BUY, 10);
        LimitOrder limit = new LimitOrder("MSFT", OrderSide.SELL, 10, 300.0);
        assertFalse(market.isLimitOrder());
        assertTrue(limit.isLimitOrder());
    }

    @Test
    void testRemainingQuantity() {
        LimitOrder order = new LimitOrder("GOOG", OrderSide.BUY, 100, 2800.0);
        assertEquals(100, order.getRemainingQuantity());
        order.setFilledQuantity(40);
        assertEquals(60, order.getRemainingQuantity());
        order.setFilledQuantity(100);
        assertEquals(0, order.getRemainingQuantity());
    }

    @Test
    void testOrderStatusTransitions() {
        LimitOrder order = new LimitOrder("AMZN", OrderSide.BUY, 100, 150.0);
        assertEquals(OrderStatus.NEW, order.getStatus());

        order.setStatus(OrderStatus.PARTIALLY_FILLED);
        assertEquals(OrderStatus.PARTIALLY_FILLED, order.getStatus());

        order.setStatus(OrderStatus.FILLED);
        assertEquals(OrderStatus.FILLED, order.getStatus());
    }

    @Test
    void testTradeCreation() {
        Trade trade = new Trade("order-1", "order-2", "AAPL", 150.25, 50);
        assertNotNull(trade.getTradeId());
        assertEquals("order-1", trade.getBuyOrderId());
        assertEquals("order-2", trade.getSellOrderId());
        assertEquals("AAPL", trade.getSymbol());
        assertEquals(150.25, trade.getPrice(), 0.001);
        assertEquals(50, trade.getQuantity());
        assertNotNull(trade.getExecutedAt());
    }

    @Test
    void testOrderToString() {
        MarketOrder market = new MarketOrder("AAPL", OrderSide.BUY, 50);
        LimitOrder limit = new LimitOrder("AAPL", OrderSide.SELL, 50, 150.0);
        assertTrue(market.toString().contains("MKT"));
        assertTrue(limit.toString().contains("150.00"));
    }
}
