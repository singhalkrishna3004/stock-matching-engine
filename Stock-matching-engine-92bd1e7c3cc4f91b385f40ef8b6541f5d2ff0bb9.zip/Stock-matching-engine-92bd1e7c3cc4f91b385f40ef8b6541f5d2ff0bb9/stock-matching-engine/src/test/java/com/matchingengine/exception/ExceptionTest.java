package com.matchingengine.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for custom exception classes.
 */
class ExceptionTest {

    @Test
    void testInvalidOrderExceptionMessage() {
        try {
            throw new InvalidOrderException("Invalid price specified");
        } catch (InvalidOrderException e) {
            assertEquals("Invalid price specified", e.getMessage());
        }
    }

    @Test
    void testInvalidOrderExceptionWithCause() {
        NumberFormatException cause = new NumberFormatException("Bad number");
        try {
            throw new InvalidOrderException("Parse failed", cause);
        } catch (InvalidOrderException e) {
            assertEquals("Parse failed", e.getMessage());
            assertSame(cause, e.getCause());
        }
    }

    @Test
    void testInsufficientQuantityExceptionMessage() {
        try {
            throw new InsufficientQuantityException("Not enough shares");
        } catch (InsufficientQuantityException e) {
            assertEquals("Not enough shares", e.getMessage());
        }
    }

    @Test
    void testOrderNotFoundExceptionMessage() {
        try {
            throw new OrderNotFoundException("Order 123 not found");
        } catch (OrderNotFoundException e) {
            assertEquals("Order 123 not found", e.getMessage());
        }
    }

    @Test
    void testExceptionsAreChecked() {
        assertTrue(Exception.class.isAssignableFrom(InvalidOrderException.class));
        assertFalse(RuntimeException.class.isAssignableFrom(InvalidOrderException.class));

        assertTrue(Exception.class.isAssignableFrom(InsufficientQuantityException.class));
        assertFalse(RuntimeException.class.isAssignableFrom(InsufficientQuantityException.class));

        assertTrue(Exception.class.isAssignableFrom(OrderNotFoundException.class));
        assertFalse(RuntimeException.class.isAssignableFrom(OrderNotFoundException.class));
    }
}
