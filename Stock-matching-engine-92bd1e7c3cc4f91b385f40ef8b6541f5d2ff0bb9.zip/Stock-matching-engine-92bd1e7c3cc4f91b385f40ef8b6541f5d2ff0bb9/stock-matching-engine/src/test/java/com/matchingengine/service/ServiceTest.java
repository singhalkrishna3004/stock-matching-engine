package com.matchingengine.service;

import com.matchingengine.dao.OrderDao;
import com.matchingengine.dao.TradeDao;
import com.matchingengine.engine.MatchingEngine;
import com.matchingengine.exception.InvalidOrderException;
import com.matchingengine.exception.OrderNotFoundException;
import com.matchingengine.model.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for OrderService and ReportService.
 */
class ServiceTest {

    private Connection connection;
    private OrderDao orderDao;
    private TradeDao tradeDao;
    private MatchingEngine engine;
    private OrderService orderService;
    private ReportService reportService;

    @BeforeEach
    void setUp() throws Exception {
        connection = DriverManager.getConnection("jdbc:sqlite::memory:");
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("schema.sql")) {
            assertNotNull(is);
            String fullSql = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            try (Statement stmt = connection.createStatement()) {
                for (String sqlStatement : fullSql.split(";")) {
                    String trimmed = sqlStatement.trim();
                    if (!trimmed.isEmpty()) {
                        stmt.execute(trimmed);
                    }
                }
            }
        }
        orderDao = new OrderDao(connection);
        tradeDao = new TradeDao(connection);
        engine = new MatchingEngine(tradeDao, orderDao);
        orderService = new OrderService(engine, orderDao);
        reportService = new ReportService(tradeDao);
    }

    @AfterEach
    void tearDown() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    // ---- OrderService Tests ----

    @Test
    void testSubmitValidLimitOrder() {
        assertDoesNotThrow(() ->
                orderService.submitLimitOrder("AAPL", OrderSide.BUY, 100, 150.0));
        assertEquals(1, orderDao.findBySymbol("AAPL").size());
    }

    @Test
    void testSubmitInvalidOrderThrows() {
        assertThrows(InvalidOrderException.class, () ->
                orderService.submitLimitOrder("AAPL", OrderSide.BUY, -10, 150.0));
        assertThrows(InvalidOrderException.class, () ->
                orderService.submitLimitOrder("", OrderSide.BUY, 10, 150.0));
        assertThrows(InvalidOrderException.class, () ->
                orderService.submitLimitOrder("AAPL", OrderSide.BUY, 10, -5.0));
    }

    @Test
    void testSubmitMarketOrder() {
        assertDoesNotThrow(() ->
                orderService.submitMarketOrder("TSLA", OrderSide.SELL, 50));
        assertEquals(1, orderDao.findBySymbol("TSLA").size());
    }

    @Test
    void testGetOrderNotFoundThrows() {
        assertThrows(OrderNotFoundException.class, () ->
                orderService.getOrder("non-existent-order-id"));
    }

    @Test
    void testCancelOrder() throws Exception {
        LimitOrder order = new LimitOrder("AAPL", OrderSide.BUY, 100, 150.0);
        orderDao.insert(order);
        engine.submitOrder(order);

        orderService.cancelOrder(order.getOrderId());
        Order cancelled = orderService.getOrder(order.getOrderId());
        assertEquals(OrderStatus.CANCELLED, cancelled.getStatus());
    }

    // ---- ReportService Tests ----

    @Test
    void testVWAPCalculation() {
        // Trade 1: 100 shares @ $10.00 = $1000
        // Trade 2: 200 shares @ $20.00 = $4000
        // Total notional = $5000, Total volume = 300, VWAP = 5000 / 300 = 16.6667
        Trade t1 = new Trade("b1", "s1", "AAPL", 10.0, 100);
        Trade t2 = new Trade("b2", "s2", "AAPL", 20.0, 200);

        // Dummy orders to satisfy foreign keys
        orderDao.insert(new LimitOrder("b1", "AAPL", OrderSide.BUY, 100, 10.0, 100, OrderStatus.FILLED, null));
        orderDao.insert(new LimitOrder("s1", "AAPL", OrderSide.SELL, 100, 10.0, 100, OrderStatus.FILLED, null));
        orderDao.insert(new LimitOrder("b2", "AAPL", OrderSide.BUY, 200, 20.0, 200, OrderStatus.FILLED, null));
        orderDao.insert(new LimitOrder("s2", "AAPL", OrderSide.SELL, 200, 20.0, 200, OrderStatus.FILLED, null));

        tradeDao.insert(t1);
        tradeDao.insert(t2);

        double vwap = reportService.calculateVWAP("AAPL");
        assertEquals(5000.0 / 300.0, vwap, 0.001);
    }

    @Test
    void testVWAPNoTrades() {
        assertEquals(0.0, reportService.calculateVWAP("UNKNOWN"), 0.001);
    }

    @Test
    void testMostActiveSymbols() {
        orderDao.insert(new LimitOrder("b1", "AAPL", OrderSide.BUY, 50, 150.0, 50, OrderStatus.FILLED, null));
        orderDao.insert(new LimitOrder("s1", "AAPL", OrderSide.SELL, 50, 150.0, 50, OrderStatus.FILLED, null));
        orderDao.insert(new LimitOrder("b2", "MSFT", OrderSide.BUY, 200, 300.0, 200, OrderStatus.FILLED, null));
        orderDao.insert(new LimitOrder("s2", "MSFT", OrderSide.SELL, 200, 300.0, 200, OrderStatus.FILLED, null));

        tradeDao.insert(new Trade("b1", "s1", "AAPL", 150.0, 50));
        tradeDao.insert(new Trade("b2", "s2", "MSFT", 300.0, 200));

        Map<String, Integer> mostActive = reportService.getMostActiveSymbols();
        assertEquals(2, mostActive.size());
        // MSFT has 200, AAPL has 50 -> MSFT should be first
        assertEquals("MSFT", mostActive.keySet().iterator().next());
        assertEquals(200, mostActive.get("MSFT"));
        assertEquals(50, mostActive.get("AAPL"));
    }

    @Test
    void testEODReportDoesNotThrow() {
        assertDoesNotThrow(() -> reportService.printEODReport());
    }

    // ---- Market Order + Invalid Input Tests ----

    @Test
    void testMarketOrderMatchesImmediately() throws Exception {
        // Start the engine so it processes the queue
        engine.start();

        // Place a resting LIMIT SELL order at $50.00 for 30 shares
        orderService.submitLimitOrder("AAPL", OrderSide.SELL, 30, 50.0);

        // Wait for the engine to process and rest the sell order
        long deadline = System.currentTimeMillis() + 5_000;
        while (engine.getPendingOrderCount() > 0 && System.currentTimeMillis() < deadline) {
            Thread.onSpinWait();
        }

        // Submit a MARKET BUY for 30 shares — should match immediately against the resting sell
        orderService.submitMarketOrder("AAPL", OrderSide.BUY, 30);

        // Wait for the engine to process the market order AND persist the trade.
        // We poll the trade DAO because the queue may drain before the worker
        // thread finishes persisting the trade to the database.
        deadline = System.currentTimeMillis() + 5_000;
        while (tradeDao.findBySymbol("AAPL").isEmpty() && System.currentTimeMillis() < deadline) {
            Thread.onSpinWait();
        }

        // Verify trades occurred — the trade should have been persisted to the DB
        assertFalse(tradeDao.findBySymbol("AAPL").isEmpty(),
                "Market BUY should have matched against the resting LIMIT SELL");
        assertEquals(30, tradeDao.findBySymbol("AAPL").get(0).getQuantity());
        assertEquals(50.0, tradeDao.findBySymbol("AAPL").get(0).getPrice(), 0.001);

        engine.stop();
    }

    @Test
    void testNegativeQuantityThrowsInvalidOrderException() {
        // Submitting a LIMIT order with negative quantity via the service layer
        // should throw InvalidOrderException — not just at the CSV parser level
        InvalidOrderException ex = assertThrows(InvalidOrderException.class, () ->
                orderService.submitLimitOrder("AAPL", OrderSide.BUY, -5, 150.0));
        assertTrue(ex.getMessage().contains("Quantity"),
                "Exception message should mention quantity validation");

        // Also verify market orders reject negative quantity
        assertThrows(InvalidOrderException.class, () ->
                orderService.submitMarketOrder("TSLA", OrderSide.SELL, -10));
    }
}
