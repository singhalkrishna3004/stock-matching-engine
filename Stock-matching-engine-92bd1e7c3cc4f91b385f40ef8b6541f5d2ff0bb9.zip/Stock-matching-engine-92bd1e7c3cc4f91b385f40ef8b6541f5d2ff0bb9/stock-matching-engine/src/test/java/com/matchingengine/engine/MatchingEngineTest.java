package com.matchingengine.engine;

import com.matchingengine.model.LimitOrder;
import com.matchingengine.model.OrderSide;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the MatchingEngine — concurrent submission, lifecycle.
 */
class MatchingEngineTest {

    private MatchingEngine engine;

    @BeforeEach
    void setUp() {
        engine = new MatchingEngine();
    }

    @Test
    void testSubmitOrderEnqueues() {
        assertEquals(0, engine.getPendingOrderCount());
        LimitOrder order = new LimitOrder("AAPL", OrderSide.BUY, 10, 150.0);
        engine.submitOrder(order);
        assertEquals(1, engine.getPendingOrderCount());
    }

    @Test
    void testEngineStartAndStop() {
        assertFalse(engine.isRunning());
        engine.start();
        assertTrue(engine.isRunning());
        engine.stop();
        assertFalse(engine.isRunning());
    }

    @Test
    void testConcurrentOrderSubmission() throws InterruptedException {
        int threadCount = 10;
        int ordersPerThread = 50;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);

        for (int i = 0; i < threadCount; i++) {
            executor.submit(() -> {
                try {
                    for (int j = 0; j < ordersPerThread; j++) {
                        engine.submitOrder(new LimitOrder("AAPL", OrderSide.BUY, 10, 150.0));
                    }
                } finally {
                    latch.countDown();
                }
            });
        }

        assertTrue(latch.await(5, TimeUnit.SECONDS));
        executor.shutdown();
        assertEquals(threadCount * ordersPerThread, engine.getPendingOrderCount());
    }

    @Test
    void testOrderBookCreatedPerSymbol() throws InterruptedException {
        engine.start();
        engine.submitOrder(new LimitOrder("AAPL", OrderSide.BUY, 10, 150.0));
        engine.submitOrder(new LimitOrder("MSFT", OrderSide.BUY, 10, 300.0));
        engine.submitOrder(new LimitOrder("GOOG", OrderSide.BUY, 10, 2800.0));

        // Allow worker loop to process orders
        Thread.sleep(300);

        assertNotNull(engine.getOrderBook("AAPL"));
        assertNotNull(engine.getOrderBook("MSFT"));
        assertNotNull(engine.getOrderBook("GOOG"));
        assertEquals(3, engine.getAllOrderBooks().size());

        engine.stop();
    }

    @Test
    void testEngineProcessesAllOrders() throws InterruptedException {
        engine.start();
        int orderCount = 20;
        for (int i = 0; i < orderCount; i++) {
            engine.submitOrder(new LimitOrder("AAPL", OrderSide.BUY, 10, 150.0));
        }

        // Wait until all pending orders in queue are drained
        long start = System.currentTimeMillis();
        while (engine.getPendingOrderCount() > 0 && (System.currentTimeMillis() - start) < 3000) {
            Thread.sleep(50);
        }

        assertEquals(0, engine.getPendingOrderCount());
        engine.stop();
    }

    @Test
    void testGracefulShutdown() throws InterruptedException {
        engine.submitOrder(new LimitOrder("AAPL", OrderSide.BUY, 10, 150.0));
        engine.submitOrder(new LimitOrder("AAPL", OrderSide.SELL, 10, 150.0));
        engine.start();

        engine.stop();
        assertFalse(engine.isRunning());
        assertEquals(0, engine.getPendingOrderCount());
    }
}
