package com.matchingengine.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for CsvOrderParser and AppLogger utilities.
 */
class UtilTest {

    // ---- CsvOrderParser Tests ----

    @Test
    void testParseValidCSV() {
        CsvOrderParser parser = new CsvOrderParser();
        CsvOrderParser.ParseResult result = parser.parse("data/orders.csv");

        assertNotNull(result);
        assertFalse(result.getValidOrders().isEmpty());
        // In data/orders.csv, 7 orders out of 10 rows are valid
        assertEquals(7, result.getValidOrders().size());
    }

    @Test
    void testParseMalformedRowsReported() {
        CsvOrderParser parser = new CsvOrderParser();
        CsvOrderParser.ParseResult result = parser.parse("data/orders.csv");

        // 3 rows are malformed (ORD004 invalid price, ORD007 negative qty, ORD010 missing qty)
        assertEquals(3, result.errorCount());
        assertEquals(10, result.totalRows());
    }

    @Test
    void testParseEmptyFile(@TempDir Path tempDir) throws IOException {
        Path emptyFile = tempDir.resolve("empty.csv");
        Files.createFile(emptyFile);

        CsvOrderParser parser = new CsvOrderParser();
        CsvOrderParser.ParseResult result = parser.parse(emptyFile.toString());

        assertEquals(0, result.getValidOrders().size());
        assertEquals(0, result.errorCount());
    }

    @Test
    void testParseFileNotFound() {
        CsvOrderParser parser = new CsvOrderParser();
        assertThrows(IllegalArgumentException.class, () -> parser.parse("non_existent_file.csv"));
    }

    // ---- AppLogger Tests ----

    @Test
    void testLoggerDoesNotThrow() {
        AppLogger logger = new AppLogger("TestContext");
        assertDoesNotThrow(() -> {
            logger.info("Info message");
            logger.warn("Warning message");
            logger.error("Error message");
            logger.error("Error with exception", new RuntimeException("boom"));
            logger.debug("Debug message");
        });
    }

    @Test
    void testLoggerFactoryMethod() {
        AppLogger logger = AppLogger.getLogger(UtilTest.class);
        assertNotNull(logger);
    }
}
