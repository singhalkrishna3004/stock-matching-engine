package com.matchingengine.dao;

import com.matchingengine.model.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for OrderDao and TradeDao — CRUD operations against an in-memory SQLite DB.
 */
class DaoTest {

    private Connection connection;
    private OrderDao orderDao;
    private TradeDao tradeDao;

    @BeforeEach
    void setUp() throws Exception {
        connection = DriverManager.getConnection("jdbc:sqlite::memory:");
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("schema.sql")) {
            assertNotNull(is, "schema.sql must be present on classpath");
            String fullSql = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            try (Statement stmt = connection.createStatement()) {
                for (String sqlStatement : fullSql.split(";")) {
                    String trimmed = sqlStatement.trim();
                    if (!trimmed.isEmpty()) {
                        stmt.execute(trimmed);
                    }
                }
            }
        }
        orderDao = new OrderDao(connection);
        tradeDao = new TradeDao(connection);
    }

    @AfterEach
    void tearDown() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    // ---- OrderDao Tests ----

    @Test
    void testInsertOrder() {
        LimitOrder order = new LimitOrder("AAPL", OrderSide.BUY, 100, 150.50);
        orderDao.insert(order);

        Optional<Order> found = orderDao.findById(order.getOrderId());
        assertTrue(found.isPresent());
        Order loaded = found.get();
        assertEquals("AAPL", loaded.getSymbol());
        assertEquals(OrderSide.BUY, loaded.getSide());
        assertEquals(100, loaded.getQuantity());
        assertEquals(150.50, loaded.getPrice(), 0.001);
        assertEquals(OrderStatus.NEW, loaded.getStatus());
    }

    @Test
    void testUpdateOrder() {
        MarketOrder order = new MarketOrder("TSLA", OrderSide.SELL, 50);
        orderDao.insert(order);

        order.setFilledQuantity(30);
        order.setStatus(OrderStatus.PARTIALLY_FILLED);
        orderDao.update(order);

        Optional<Order> found = orderDao.findById(order.getOrderId());
        assertTrue(found.isPresent());
        assertEquals(30, found.get().getFilledQuantity());
        assertEquals(OrderStatus.PARTIALLY_FILLED, found.get().getStatus());
    }

    @Test
    void testFindBySymbol() {
        orderDao.insert(new LimitOrder("AAPL", OrderSide.BUY, 10, 150.0));
        orderDao.insert(new LimitOrder("AAPL", OrderSide.SELL, 20, 155.0));
        orderDao.insert(new LimitOrder("MSFT", OrderSide.BUY, 30, 310.0));

        List<Order> aaplOrders = orderDao.findBySymbol("AAPL");
        assertEquals(2, aaplOrders.size());
        assertTrue(aaplOrders.stream().allMatch(o -> "AAPL".equals(o.getSymbol())));
    }

    @Test
    void testFindAllOrders() {
        orderDao.insert(new LimitOrder("AAPL", OrderSide.BUY, 10, 150.0));
        orderDao.insert(new MarketOrder("GOOG", OrderSide.SELL, 20));

        List<Order> all = orderDao.findAll();
        assertEquals(2, all.size());
    }

    @Test
    void testDeleteOrder() {
        LimitOrder order = new LimitOrder("NVDA", OrderSide.BUY, 25, 450.0);
        orderDao.insert(order);

        assertTrue(orderDao.deleteById(order.getOrderId()));
        assertFalse(orderDao.findById(order.getOrderId()).isPresent());
    }

    // ---- TradeDao Tests ----

    @Test
    void testInsertTrade() {
        LimitOrder buy = new LimitOrder("AAPL", OrderSide.BUY, 100, 150.0);
        LimitOrder sell = new LimitOrder("AAPL", OrderSide.SELL, 100, 150.0);
        orderDao.insert(buy);
        orderDao.insert(sell);

        Trade trade = new Trade(buy.getOrderId(), sell.getOrderId(), "AAPL", 150.0, 100);
        tradeDao.insert(trade);

        Optional<Trade> found = tradeDao.findById(trade.getTradeId());
        assertTrue(found.isPresent());
        assertEquals(trade.getTradeId(), found.get().getTradeId());
        assertEquals(150.0, found.get().getPrice(), 0.001);
        assertEquals(100, found.get().getQuantity());
    }

    @Test
    void testFindTradesBySymbol() {
        LimitOrder b1 = new LimitOrder("AAPL", OrderSide.BUY, 10, 150.0);
        LimitOrder s1 = new LimitOrder("AAPL", OrderSide.SELL, 10, 150.0);
        LimitOrder b2 = new LimitOrder("MSFT", OrderSide.BUY, 20, 300.0);
        LimitOrder s2 = new LimitOrder("MSFT", OrderSide.SELL, 20, 300.0);
        orderDao.insert(b1);
        orderDao.insert(s1);
        orderDao.insert(b2);
        orderDao.insert(s2);

        tradeDao.insert(new Trade(b1.getOrderId(), s1.getOrderId(), "AAPL", 150.0, 10));
        tradeDao.insert(new Trade(b2.getOrderId(), s2.getOrderId(), "MSFT", 300.0, 20));

        List<Trade> aaplTrades = tradeDao.findBySymbol("AAPL");
        assertEquals(1, aaplTrades.size());
        assertEquals("AAPL", aaplTrades.get(0).getSymbol());
    }

    @Test
    void testInsertAuditLog() {
        assertDoesNotThrow(() ->
                tradeDao.insertAuditLog("TEST_EVENT", "REF123", "Test details message"));
    }
}
