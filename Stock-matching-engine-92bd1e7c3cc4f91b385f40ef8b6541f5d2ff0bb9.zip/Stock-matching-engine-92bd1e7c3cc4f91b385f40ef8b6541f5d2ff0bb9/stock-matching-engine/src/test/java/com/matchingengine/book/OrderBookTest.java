package com.matchingengine.book;

import com.matchingengine.model.LimitOrder;
import com.matchingengine.model.OrderSide;
import com.matchingengine.model.OrderStatus;
import com.matchingengine.model.Trade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the OrderBook — price-time priority matching, add/cancel.
 */
class OrderBookTest {

    private OrderBook orderBook;

    @BeforeEach
    void setUp() {
        orderBook = new OrderBook("AAPL");
    }

    @Test
    void testAddBuyOrder() {
        LimitOrder buy = new LimitOrder("AAPL", OrderSide.BUY, 100, 150.0);
        orderBook.addOrder(buy);

        assertEquals(1, orderBook.size());
        assertTrue(orderBook.getBids().containsKey(150.0));
        assertEquals(1, orderBook.getBids().get(150.0).size());
    }

    @Test
    void testAddSellOrder() {
        LimitOrder sell = new LimitOrder("AAPL", OrderSide.SELL, 50, 155.0);
        orderBook.addOrder(sell);

        assertEquals(1, orderBook.size());
        assertTrue(orderBook.getAsks().containsKey(155.0));
        assertEquals(1, orderBook.getAsks().get(155.0).size());
    }

    @Test
    void testMatchBuyAgainstSell() {
        LimitOrder restingSell = new LimitOrder("AAPL", OrderSide.SELL, 50, 150.0);
        orderBook.addOrder(restingSell);

        LimitOrder crossingBuy = new LimitOrder("AAPL", OrderSide.BUY, 50, 150.0);
        List<Trade> trades = orderBook.match(crossingBuy);

        assertEquals(1, trades.size());
        Trade trade = trades.get(0);
        assertEquals(50, trade.getQuantity());
        assertEquals(150.0, trade.getPrice(), 0.001);
        assertEquals(OrderStatus.FILLED, crossingBuy.getStatus());
        assertEquals(OrderStatus.FILLED, restingSell.getStatus());
        assertEquals(0, orderBook.size());
    }

    @Test
    void testMatchSellAgainstBuy() {
        LimitOrder restingBuy = new LimitOrder("AAPL", OrderSide.BUY, 40, 152.0);
        orderBook.addOrder(restingBuy);

        LimitOrder crossingSell = new LimitOrder("AAPL", OrderSide.SELL, 40, 150.0);
        List<Trade> trades = orderBook.match(crossingSell);

        assertEquals(1, trades.size());
        Trade trade = trades.get(0);
        assertEquals(40, trade.getQuantity());
        assertEquals(152.0, trade.getPrice(), 0.001); // Trade executes at resting order's price
        assertEquals(OrderStatus.FILLED, crossingSell.getStatus());
        assertEquals(OrderStatus.FILLED, restingBuy.getStatus());
    }

    @Test
    void testPartialFill() {
        LimitOrder restingSell = new LimitOrder("AAPL", OrderSide.SELL, 30, 150.0);
        orderBook.addOrder(restingSell);

        LimitOrder largeBuy = new LimitOrder("AAPL", OrderSide.BUY, 100, 150.0);
        List<Trade> trades = orderBook.match(largeBuy);

        assertEquals(1, trades.size());
        assertEquals(30, trades.get(0).getQuantity());
        assertEquals(30, largeBuy.getFilledQuantity());
        assertEquals(70, largeBuy.getRemainingQuantity());
        assertEquals(OrderStatus.PARTIALLY_FILLED, largeBuy.getStatus());

        // Remaining 70 shares of buy order should now rest on the book
        assertEquals(1, orderBook.size());
        assertTrue(orderBook.getBestBid().isPresent());
        assertEquals(150.0, orderBook.getBestBid().getAsDouble(), 0.001);
    }

    @Test
    void testPriceTimePriority() {
        LimitOrder sell1 = new LimitOrder("AAPL", OrderSide.SELL, 20, 150.0);
        LimitOrder sell2 = new LimitOrder("AAPL", OrderSide.SELL, 30, 150.0);
        orderBook.addOrder(sell1);
        orderBook.addOrder(sell2);

        LimitOrder buy = new LimitOrder("AAPL", OrderSide.BUY, 25, 150.0);
        List<Trade> trades = orderBook.match(buy);

        // FIFO: sell1 must be matched first completely (20 shares), then 5 shares of sell2
        assertEquals(2, trades.size());
        assertEquals(sell1.getOrderId(), trades.get(0).getSellOrderId());
        assertEquals(20, trades.get(0).getQuantity());

        assertEquals(sell2.getOrderId(), trades.get(1).getSellOrderId());
        assertEquals(5, trades.get(1).getQuantity());

        assertEquals(OrderStatus.FILLED, sell1.getStatus());
        assertEquals(OrderStatus.PARTIALLY_FILLED, sell2.getStatus());
        assertEquals(25, sell2.getRemainingQuantity());
    }

    @Test
    void testNoMatchWhenPricesDontCross() {
        LimitOrder sell = new LimitOrder("AAPL", OrderSide.SELL, 50, 160.0);
        orderBook.addOrder(sell);

        LimitOrder buy = new LimitOrder("AAPL", OrderSide.BUY, 50, 150.0);
        List<Trade> trades = orderBook.match(buy);

        assertTrue(trades.isEmpty());
        assertEquals(2, orderBook.size());
        assertEquals(OrderStatus.NEW, buy.getStatus());
        assertEquals(OrderStatus.NEW, sell.getStatus());
    }

    @Test
    void testCancelOrder() {
        LimitOrder buy = new LimitOrder("AAPL", OrderSide.BUY, 50, 150.0);
        orderBook.addOrder(buy);
        assertEquals(1, orderBook.size());

        assertTrue(orderBook.cancelOrder(buy.getOrderId()));
        assertEquals(0, orderBook.size());
        assertEquals(OrderStatus.CANCELLED, buy.getStatus());
        assertFalse(orderBook.cancelOrder("non-existent-id"));
    }

    @Test
    void testBestBidAsk() {
        assertFalse(orderBook.getBestBid().isPresent());
        assertFalse(orderBook.getBestAsk().isPresent());

        orderBook.addOrder(new LimitOrder("AAPL", OrderSide.BUY, 10, 148.0));
        orderBook.addOrder(new LimitOrder("AAPL", OrderSide.BUY, 10, 152.0));
        orderBook.addOrder(new LimitOrder("AAPL", OrderSide.SELL, 10, 155.0));
        orderBook.addOrder(new LimitOrder("AAPL", OrderSide.SELL, 10, 158.0));

        assertEquals(152.0, orderBook.getBestBid().getAsDouble(), 0.001); // Highest bid
        assertEquals(155.0, orderBook.getBestAsk().getAsDouble(), 0.001); // Lowest ask
    }

    @Test
    void testBookSize() {
        assertEquals(0, orderBook.size());
        orderBook.addOrder(new LimitOrder("AAPL", OrderSide.BUY, 10, 150.0));
        orderBook.addOrder(new LimitOrder("AAPL", OrderSide.BUY, 10, 151.0));
        orderBook.addOrder(new LimitOrder("AAPL", OrderSide.SELL, 10, 155.0));
        assertEquals(3, orderBook.size());
    }
}
