-- ============================================================
-- Stock Matching Engine — SQLite Schema
-- ============================================================

CREATE TABLE IF NOT EXISTS orders (
    order_id    TEXT PRIMARY KEY,
    symbol      TEXT    NOT NULL,
    side        TEXT    NOT NULL CHECK (side IN ('BUY', 'SELL')),
    order_type  TEXT    NOT NULL CHECK (order_type IN ('MARKET', 'LIMIT')),
    price       REAL,                       -- NULL for market orders
    quantity    INTEGER NOT NULL CHECK (quantity > 0),
    filled_qty  INTEGER NOT NULL DEFAULT 0,
    status      TEXT    NOT NULL DEFAULT 'NEW'
                        CHECK (status IN ('NEW', 'PARTIALLY_FILLED', 'FILLED', 'CANCELLED')),
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS trades (
    trade_id        TEXT PRIMARY KEY,
    buy_order_id    TEXT NOT NULL REFERENCES orders(order_id),
    sell_order_id   TEXT NOT NULL REFERENCES orders(order_id),
    symbol          TEXT NOT NULL,
    price           REAL NOT NULL,
    quantity        INTEGER NOT NULL CHECK (quantity > 0),
    executed_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
    log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type  TEXT    NOT NULL,        -- e.g. ORDER_SUBMITTED, ORDER_MATCHED, ORDER_CANCELLED
    reference_id TEXT,                   -- order_id or trade_id
    details     TEXT,                    -- free-form JSON or description
    logged_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Index for fast symbol-based lookups
CREATE INDEX IF NOT EXISTS idx_orders_symbol  ON orders(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_symbol  ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_audit_event    ON audit_log(event_type);
