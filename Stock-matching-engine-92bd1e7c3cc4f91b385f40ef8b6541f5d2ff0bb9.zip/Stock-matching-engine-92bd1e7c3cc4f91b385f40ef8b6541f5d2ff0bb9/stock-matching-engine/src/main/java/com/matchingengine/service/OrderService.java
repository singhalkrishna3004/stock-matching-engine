package com.matchingengine.service;

import com.matchingengine.dao.OrderDao;
import com.matchingengine.engine.MatchingEngine;
import com.matchingengine.exception.InvalidOrderException;
import com.matchingengine.exception.OrderNotFoundException;
import com.matchingengine.model.*;
import com.matchingengine.book.OrderBook;

/**
 * High-level service for order submission, validation, and lifecycle management.
 * Acts as the bridge between the CLI and the matching engine.
 */
public class OrderService {

    private final MatchingEngine matchingEngine;
    private final OrderDao orderDao;

    public OrderService(MatchingEngine matchingEngine, OrderDao orderDao) {
        this.matchingEngine = matchingEngine;
        this.orderDao = orderDao;
    }

    // ----------------------------------------------------------------
    //  Order Submission
    // ----------------------------------------------------------------

    /**
     * Validates and submits a new limit order.
     *
     * @param symbol   stock symbol
     * @param side     BUY or SELL
     * @param quantity number of shares
     * @param price    limit price (must be > 0)
     * @throws InvalidOrderException if validation fails
     */
    public void submitLimitOrder(String symbol, OrderSide side, int quantity, double price)
            throws InvalidOrderException {
        validateCommon(symbol, side, quantity);
        if (price <= 0) {
            throw new InvalidOrderException("Limit price must be greater than zero");
        }

        LimitOrder order = new LimitOrder(symbol.trim().toUpperCase(), side, quantity, price);
        if (orderDao != null) {
            orderDao.insert(order);
        }
        if (matchingEngine != null) {
            matchingEngine.submitOrder(order);
        }
    }

    /**
     * Validates and submits a new market order.
     *
     * @param symbol   stock symbol
     * @param side     BUY or SELL
     * @param quantity number of shares
     * @throws InvalidOrderException if validation fails
     */
    public void submitMarketOrder(String symbol, OrderSide side, int quantity)
            throws InvalidOrderException {
        validateCommon(symbol, side, quantity);

        MarketOrder order = new MarketOrder(symbol.trim().toUpperCase(), side, quantity);
        if (orderDao != null) {
            orderDao.insert(order);
        }
        if (matchingEngine != null) {
            matchingEngine.submitOrder(order);
        }
    }

    private void validateCommon(String symbol, OrderSide side, int quantity) throws InvalidOrderException {
        if (symbol == null || symbol.trim().isEmpty()) {
            throw new InvalidOrderException("Symbol cannot be empty");
        }
        if (side == null) {
            throw new InvalidOrderException("Order side cannot be null");
        }
        if (quantity <= 0) {
            throw new InvalidOrderException("Quantity must be greater than zero");
        }
    }

    // ----------------------------------------------------------------
    //  Order Queries
    // ----------------------------------------------------------------

    /**
     * Retrieves an order by ID, throwing if not found.
     *
     * @param orderId the order ID
     * @return the order
     * @throws OrderNotFoundException if the order does not exist
     */
    public Order getOrder(String orderId) throws OrderNotFoundException {
        if (orderId == null || orderDao == null) {
            throw new OrderNotFoundException("Order not found: " + orderId);
        }
        return orderDao.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found: " + orderId));
    }

    /**
     * Cancels an open order.
     *
     * @param orderId the order ID to cancel
     * @throws OrderNotFoundException if the order does not exist
     */
    public void cancelOrder(String orderId) throws OrderNotFoundException {
        Order order = getOrder(orderId);

        if (order.getStatus() != OrderStatus.FILLED && order.getStatus() != OrderStatus.CANCELLED) {
            if (matchingEngine != null) {
                OrderBook book = matchingEngine.getOrderBook(order.getSymbol());
                if (book != null) {
                    book.cancelOrder(orderId);
                }
            }
            order.setStatus(OrderStatus.CANCELLED);
            if (orderDao != null) {
                orderDao.update(order);
            }
        }
    }
}
