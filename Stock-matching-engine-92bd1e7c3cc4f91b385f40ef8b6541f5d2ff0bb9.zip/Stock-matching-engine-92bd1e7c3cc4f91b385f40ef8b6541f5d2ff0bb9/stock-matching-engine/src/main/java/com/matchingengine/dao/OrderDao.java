package com.matchingengine.dao;

import com.matchingengine.model.*;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for the {@code orders} table.
 * Uses JDBC with SQLite and PreparedStatements throughout.
 */
public class OrderDao {

    private static final DateTimeFormatter SQLITE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final Connection connection;

    public OrderDao(Connection connection) {
        this.connection = connection;
    }

    // ----------------------------------------------------------------
    //  CRUD Operations
    // ----------------------------------------------------------------

    /**
     * Inserts a new order into the database.
     *
     * @param order the order to persist
     */
    public void insert(Order order) {
        String sql = "INSERT INTO orders (order_id, symbol, side, order_type, price, quantity, filled_qty, status, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, order.getOrderId());
            ps.setString(2, order.getSymbol());
            ps.setString(3, order.getSide().name());
            ps.setString(4, order.isLimitOrder() ? "LIMIT" : "MARKET");
            if (order.isLimitOrder()) {
                ps.setDouble(5, order.getPrice());
            } else {
                ps.setNull(5, Types.REAL);
            }
            ps.setInt(6, order.getQuantity());
            ps.setInt(7, order.getFilledQuantity());
            ps.setString(8, order.getStatus().name());
            ps.setString(9, order.getCreatedAt() != null ? order.getCreatedAt().toString() : LocalDateTime.now().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error inserting order: " + order.getOrderId(), e);
        }
    }

    /**
     * Updates the filled quantity and status of an existing order.
     *
     * @param order the order with updated fields
     */
    public void update(Order order) {
        String sql = "UPDATE orders SET filled_qty = ?, status = ?, updated_at = datetime('now') WHERE order_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, order.getFilledQuantity());
            ps.setString(2, order.getStatus().name());
            ps.setString(3, order.getOrderId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating order: " + order.getOrderId(), e);
        }
    }

    /**
     * Finds an order by its ID.
     *
     * @param orderId the order ID
     * @return the order, or empty if not found
     */
    public Optional<Order> findById(String orderId) {
        String sql = "SELECT * FROM orders WHERE order_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToOrder(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding order by ID: " + orderId, e);
        }
        return Optional.empty();
    }

    /**
     * Returns all orders for a given symbol.
     *
     * @param symbol the stock symbol
     * @return list of orders (may be empty)
     */
    public List<Order> findBySymbol(String symbol) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE symbol = ? ORDER BY created_at";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, symbol);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    orders.add(mapResultSetToOrder(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding orders by symbol: " + symbol, e);
        }
        return orders;
    }

    /**
     * Returns all orders in the database.
     *
     * @return list of all orders
     */
    public List<Order> findAll() {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders ORDER BY created_at";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding all orders", e);
        }
        return orders;
    }

    /**
     * Deletes an order by its ID.
     *
     * @param orderId the order ID to delete
     * @return true if a row was deleted
     */
    public boolean deleteById(String orderId) {
        String sql = "DELETE FROM orders WHERE order_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, orderId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting order: " + orderId, e);
        }
    }

    private Order mapResultSetToOrder(ResultSet rs) throws SQLException {
        String orderId = rs.getString("order_id");
        String symbol = rs.getString("symbol");
        OrderSide side = OrderSide.valueOf(rs.getString("side"));
        String orderType = rs.getString("order_type");
        int quantity = rs.getInt("quantity");
        int filledQty = rs.getInt("filled_qty");
        OrderStatus status = OrderStatus.valueOf(rs.getString("status"));
        LocalDateTime createdAt = parseDateTime(rs.getString("created_at"));

        if ("LIMIT".equalsIgnoreCase(orderType)) {
            double price = rs.getDouble("price");
            return new LimitOrder(orderId, symbol, side, quantity, price, filledQty, status, createdAt);
        } else {
            return new MarketOrder(orderId, symbol, side, quantity, filledQty, status, createdAt);
        }
    }

    private LocalDateTime parseDateTime(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            return LocalDateTime.now();
        }
        try {
            return LocalDateTime.parse(raw);
        } catch (Exception ignored) {
            try {
                return LocalDateTime.parse(raw, SQLITE_FMT);
            } catch (Exception ex) {
                return LocalDateTime.now();
            }
        }
    }
}
