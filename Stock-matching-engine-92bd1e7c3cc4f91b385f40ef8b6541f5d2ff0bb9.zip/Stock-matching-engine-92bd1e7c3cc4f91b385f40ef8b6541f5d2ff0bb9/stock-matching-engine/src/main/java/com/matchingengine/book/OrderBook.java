package com.matchingengine.book;

import com.matchingengine.model.Order;
import com.matchingengine.model.OrderSide;
import com.matchingengine.model.OrderStatus;
import com.matchingengine.model.Trade;

import java.util.*;

/**
 * Order book maintaining bid (buy) and ask (sell) sides.
 *
 * <p>Structure:
 * <ul>
 *   <li>Bids — TreeMap keyed by price <b>descending</b> (highest bid first)</li>
 *   <li>Asks — TreeMap keyed by price <b>ascending</b>  (lowest ask first)</li>
 * </ul>
 * Each price level maps to a FIFO queue of orders (time priority).
 */
public class OrderBook {

    private final String symbol;

    // Bids: highest price first → descending comparator
    private final TreeMap<Double, Queue<Order>> bids = new TreeMap<>(Comparator.reverseOrder());

    // Asks: lowest price first → natural order
    private final TreeMap<Double, Queue<Order>> asks = new TreeMap<>();

    public OrderBook(String symbol) {
        this.symbol = symbol;
    }

    // ----------------------------------------------------------------
    //  Add an order to the appropriate side of the book
    // ----------------------------------------------------------------

    /**
     * Adds an order to the bid or ask side based on its {@code OrderSide}.
     *
     * @param order the order to add
     */
    public synchronized void addOrder(Order order) {
        if (order == null || order.getRemainingQuantity() <= 0) {
            return;
        }
        double price = order.getPrice();
        if (order.getSide() == OrderSide.BUY) {
            bids.computeIfAbsent(price, k -> new LinkedList<>()).add(order);
        } else {
            asks.computeIfAbsent(price, k -> new LinkedList<>()).add(order);
        }
    }

    // ----------------------------------------------------------------
    //  Match incoming order against resting orders
    // ----------------------------------------------------------------

    /**
     * Attempts to match the given incoming order against the opposite side
     * of the book using price-time priority.
     *
     * @param incomingOrder the aggressive order to match
     * @return list of trades generated (may be empty if no match)
     */
    public synchronized List<Trade> match(Order incomingOrder) {
        List<Trade> trades = new ArrayList<>();
        if (incomingOrder == null || incomingOrder.getRemainingQuantity() <= 0) {
            return trades;
        }

        if (incomingOrder.getSide() == OrderSide.BUY) {
            matchBuy(incomingOrder, trades);
        } else {
            matchSell(incomingOrder, trades);
        }

        return trades;
    }

    private void matchBuy(Order incomingBuy, List<Trade> trades) {
        Iterator<Map.Entry<Double, Queue<Order>>> askEntryIter = asks.entrySet().iterator();

        while (askEntryIter.hasNext() && incomingBuy.getRemainingQuantity() > 0) {
            Map.Entry<Double, Queue<Order>> entry = askEntryIter.next();
            double askPrice = entry.getKey();

            // For limit order, cannot match if lowest ask exceeds limit price
            if (incomingBuy.isLimitOrder() && askPrice > incomingBuy.getPrice()) {
                break;
            }

            Queue<Order> restingAsks = entry.getValue();
            Iterator<Order> queueIter = restingAsks.iterator();

            while (queueIter.hasNext() && incomingBuy.getRemainingQuantity() > 0) {
                Order restingAsk = queueIter.next();
                int matchQty = Math.min(incomingBuy.getRemainingQuantity(), restingAsk.getRemainingQuantity());
                if (matchQty <= 0) {
                    continue;
                }

                double tradePrice = restingAsk.getPrice();
                Trade trade = new Trade(incomingBuy.getOrderId(), restingAsk.getOrderId(), symbol, tradePrice, matchQty);
                trades.add(trade);

                incomingBuy.setFilledQuantity(incomingBuy.getFilledQuantity() + matchQty);
                restingAsk.setFilledQuantity(restingAsk.getFilledQuantity() + matchQty);

                incomingBuy.setStatus(incomingBuy.getRemainingQuantity() == 0 ? OrderStatus.FILLED : OrderStatus.PARTIALLY_FILLED);
                restingAsk.setStatus(restingAsk.getRemainingQuantity() == 0 ? OrderStatus.FILLED : OrderStatus.PARTIALLY_FILLED);

                if (restingAsk.getRemainingQuantity() == 0) {
                    queueIter.remove();
                }
            }

            if (restingAsks.isEmpty()) {
                askEntryIter.remove();
            }
        }

        // If limit order has remainder, rest it on the bid book
        if (incomingBuy.getRemainingQuantity() > 0) {
            if (incomingBuy.isLimitOrder()) {
                addOrder(incomingBuy);
            } else {
                // Market order cannot rest; if unfulfilled, cancel unfilled portion
                if (incomingBuy.getFilledQuantity() == 0) {
                    incomingBuy.setStatus(OrderStatus.CANCELLED);
                }
            }
        }
    }

    private void matchSell(Order incomingSell, List<Trade> trades) {
        Iterator<Map.Entry<Double, Queue<Order>>> bidEntryIter = bids.entrySet().iterator();

        while (bidEntryIter.hasNext() && incomingSell.getRemainingQuantity() > 0) {
            Map.Entry<Double, Queue<Order>> entry = bidEntryIter.next();
            double bidPrice = entry.getKey();

            // For limit order, cannot match if highest bid is below limit price
            if (incomingSell.isLimitOrder() && bidPrice < incomingSell.getPrice()) {
                break;
            }

            Queue<Order> restingBids = entry.getValue();
            Iterator<Order> queueIter = restingBids.iterator();

            while (queueIter.hasNext() && incomingSell.getRemainingQuantity() > 0) {
                Order restingBid = queueIter.next();
                int matchQty = Math.min(incomingSell.getRemainingQuantity(), restingBid.getRemainingQuantity());
                if (matchQty <= 0) {
                    continue;
                }

                double tradePrice = restingBid.getPrice();
                Trade trade = new Trade(restingBid.getOrderId(), incomingSell.getOrderId(), symbol, tradePrice, matchQty);
                trades.add(trade);

                incomingSell.setFilledQuantity(incomingSell.getFilledQuantity() + matchQty);
                restingBid.setFilledQuantity(restingBid.getFilledQuantity() + matchQty);

                incomingSell.setStatus(incomingSell.getRemainingQuantity() == 0 ? OrderStatus.FILLED : OrderStatus.PARTIALLY_FILLED);
                restingBid.setStatus(restingBid.getRemainingQuantity() == 0 ? OrderStatus.FILLED : OrderStatus.PARTIALLY_FILLED);

                if (restingBid.getRemainingQuantity() == 0) {
                    queueIter.remove();
                }
            }

            if (restingBids.isEmpty()) {
                bidEntryIter.remove();
            }
        }

        // If limit order has remainder, rest it on the ask book
        if (incomingSell.getRemainingQuantity() > 0) {
            if (incomingSell.isLimitOrder()) {
                addOrder(incomingSell);
            } else {
                if (incomingSell.getFilledQuantity() == 0) {
                    incomingSell.setStatus(OrderStatus.CANCELLED);
                }
            }
        }
    }

    // ----------------------------------------------------------------
    //  Cancel an order
    // ----------------------------------------------------------------

    /**
     * Removes an order from the book by its order ID.
     *
     * @param orderId the ID of the order to cancel
     * @return true if the order was found and removed
     */
    public synchronized boolean cancelOrder(String orderId) {
        if (orderId == null) {
            return false;
        }

        if (cancelFromSide(bids, orderId)) {
            return true;
        }
        return cancelFromSide(asks, orderId);
    }

    private boolean cancelFromSide(TreeMap<Double, Queue<Order>> side, String orderId) {
        Iterator<Map.Entry<Double, Queue<Order>>> entryIter = side.entrySet().iterator();
        while (entryIter.hasNext()) {
            Map.Entry<Double, Queue<Order>> entry = entryIter.next();
            Queue<Order> queue = entry.getValue();
            Iterator<Order> queueIter = queue.iterator();
            while (queueIter.hasNext()) {
                Order order = queueIter.next();
                if (orderId.equals(order.getOrderId())) {
                    queueIter.remove();
                    order.setStatus(OrderStatus.CANCELLED);
                    if (queue.isEmpty()) {
                        entryIter.remove();
                    }
                    return true;
                }
            }
        }
        return false;
    }

    // ----------------------------------------------------------------
    //  Queries
    // ----------------------------------------------------------------

    /**
     * Returns the best (highest) bid price, or empty if no bids.
     */
    public synchronized OptionalDouble getBestBid() {
        if (bids.isEmpty()) {
            return OptionalDouble.empty();
        }
        return OptionalDouble.of(bids.firstKey());
    }

    /**
     * Returns the best (lowest) ask price, or empty if no asks.
     */
    public synchronized OptionalDouble getBestAsk() {
        if (asks.isEmpty()) {
            return OptionalDouble.empty();
        }
        return OptionalDouble.of(asks.firstKey());
    }

    /**
     * Returns a read-only snapshot of the bid side.
     */
    public synchronized SortedMap<Double, Queue<Order>> getBids() {
        return Collections.unmodifiableSortedMap(new TreeMap<>(bids));
    }

    /**
     * Returns a read-only snapshot of the ask side.
     */
    public synchronized SortedMap<Double, Queue<Order>> getAsks() {
        return Collections.unmodifiableSortedMap(new TreeMap<>(asks));
    }

    /**
     * Returns the total number of resting orders (both sides).
     */
    public synchronized int size() {
        int count = 0;
        for (Queue<Order> q : bids.values()) {
            count += q.size();
        }
        for (Queue<Order> q : asks.values()) {
            count += q.size();
        }
        return count;
    }

    public String getSymbol() {
        return symbol;
    }

    @Override
    public synchronized String toString() {
        return String.format("OrderBook[%s] bids=%d levels, asks=%d levels",
                symbol, bids.size(), asks.size());
    }
}
