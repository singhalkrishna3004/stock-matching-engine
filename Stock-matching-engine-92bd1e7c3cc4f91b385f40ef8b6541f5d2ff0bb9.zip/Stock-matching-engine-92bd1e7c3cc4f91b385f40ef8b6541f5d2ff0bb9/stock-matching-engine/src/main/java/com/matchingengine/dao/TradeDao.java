package com.matchingengine.dao;

import com.matchingengine.model.Trade;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for the {@code trades} table and {@code audit_log} table.
 * Uses JDBC with SQLite and PreparedStatements throughout.
 */
public class TradeDao {

    private static final DateTimeFormatter SQLITE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final Connection connection;

    public TradeDao(Connection connection) {
        this.connection = connection;
    }

    // ----------------------------------------------------------------
    //  CRUD Operations
    // ----------------------------------------------------------------

    /**
     * Inserts a new trade record.
     *
     * @param trade the trade to persist
     */
    public void insert(Trade trade) {
        String sql = "INSERT INTO trades (trade_id, buy_order_id, sell_order_id, symbol, price, quantity, executed_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, trade.getTradeId());
            ps.setString(2, trade.getBuyOrderId());
            ps.setString(3, trade.getSellOrderId());
            ps.setString(4, trade.getSymbol());
            ps.setDouble(5, trade.getPrice());
            ps.setInt(6, trade.getQuantity());
            ps.setString(7, trade.getExecutedAt() != null ? trade.getExecutedAt().toString() : LocalDateTime.now().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error inserting trade: " + trade.getTradeId(), e);
        }
    }

    /**
     * Finds a trade by its ID.
     *
     * @param tradeId the trade ID
     * @return the trade, or empty if not found
     */
    public Optional<Trade> findById(String tradeId) {
        String sql = "SELECT * FROM trades WHERE trade_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, tradeId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToTrade(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding trade by ID: " + tradeId, e);
        }
        return Optional.empty();
    }

    /**
     * Returns all trades for a given symbol.
     *
     * @param symbol the stock symbol
     * @return list of trades (may be empty)
     */
    public List<Trade> findBySymbol(String symbol) {
        List<Trade> trades = new ArrayList<>();
        String sql = "SELECT * FROM trades WHERE symbol = ? ORDER BY executed_at";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, symbol);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    trades.add(mapResultSetToTrade(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding trades by symbol: " + symbol, e);
        }
        return trades;
    }

    /**
     * Returns all trades in the database.
     *
     * @return list of all trades
     */
    public List<Trade> findAll() {
        List<Trade> trades = new ArrayList<>();
        String sql = "SELECT * FROM trades ORDER BY executed_at";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                trades.add(mapResultSetToTrade(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding all trades", e);
        }
        return trades;
    }

    /**
     * Writes an entry to the audit_log table.
     *
     * @param eventType   e.g. ORDER_SUBMITTED, ORDER_MATCHED, ORDER_CANCELLED
     * @param referenceId the related order_id or trade_id
     * @param details     free-form description or JSON
     */
    public void insertAuditLog(String eventType, String referenceId, String details) {
        String sql = "INSERT INTO audit_log (event_type, reference_id, details) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, eventType);
            ps.setString(2, referenceId);
            ps.setString(3, details);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error writing to audit_log", e);
        }
    }

    private Trade mapResultSetToTrade(ResultSet rs) throws SQLException {
        String tradeId = rs.getString("trade_id");
        String buyOrderId = rs.getString("buy_order_id");
        String sellOrderId = rs.getString("sell_order_id");
        String symbol = rs.getString("symbol");
        double price = rs.getDouble("price");
        int quantity = rs.getInt("quantity");
        LocalDateTime executedAt = parseDateTime(rs.getString("executed_at"));

        return new Trade(tradeId, buyOrderId, sellOrderId, symbol, price, quantity, executedAt);
    }

    private LocalDateTime parseDateTime(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            return LocalDateTime.now();
        }
        try {
            return LocalDateTime.parse(raw);
        } catch (Exception ignored) {
            try {
                return LocalDateTime.parse(raw, SQLITE_FMT);
            } catch (Exception ex) {
                return LocalDateTime.now();
            }
        }
    }
}
