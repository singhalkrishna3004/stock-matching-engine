package com.matchingengine;

import com.matchingengine.book.OrderBook;
import com.matchingengine.dao.OrderDao;
import com.matchingengine.dao.TradeDao;
import com.matchingengine.engine.MatchingEngine;
import com.matchingengine.exception.InvalidOrderException;
import com.matchingengine.model.*;
import com.matchingengine.service.OrderService;
import com.matchingengine.service.ReportService;
import com.matchingengine.util.AppLogger;
import com.matchingengine.util.CsvOrderParser;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;

/**
 * CLI entry point for the Stock Matching Engine.
 *
 * <p>Initializes the database, starts the matching engine thread,
 * and presents an interactive menu loop.
 */
public class Main {

    private static final AppLogger LOG = AppLogger.getLogger(Main.class);
    private static final String DB_URL = "jdbc:sqlite:stock_engine.db";

    private static Connection connection;
    private static OrderDao orderDao;
    private static TradeDao tradeDao;
    private static MatchingEngine engine;
    private static OrderService orderService;
    private static ReportService reportService;

    public static void main(String[] args) {
        LOG.info("Starting Stock Matching Engine...");

        try {
            // Initialize SQLite connection and apply schema.sql
            connection = DriverManager.getConnection(DB_URL);
            initSchema(connection);

            // Instantiate DAOs
            orderDao = new OrderDao(connection);
            tradeDao = new TradeDao(connection);

            // Instantiate and start matching engine
            engine = new MatchingEngine(tradeDao, orderDao);
            engine.start();

            // Instantiate services
            orderService = new OrderService(engine, orderDao);
            reportService = new ReportService(tradeDao);

        } catch (Exception e) {
            LOG.error("Failed to initialize database and engine: " + e.getMessage(), e);
            System.err.println("Fatal Error during initialization: " + e.getMessage());
            return;
        }

        // --- Interactive CLI Menu ---
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> handleSubmitOrder(scanner);
                case "2" -> handleViewOrderBook(scanner);
                case "3" -> handleImportCSV(scanner);
                case "4" -> handleRunReport(scanner);
                case "5" -> {
                    LOG.info("Shutting down engine and closing database...");
                    engine.stop();
                    try {
                        if (connection != null && !connection.isClosed()) {
                            connection.close();
                        }
                    } catch (SQLException e) {
                        LOG.error("Error closing connection", e);
                    }
                    running = false;
                }
                default -> System.out.println("Invalid option. Please choose 1 - 5.");
            }
        }

        scanner.close();
        LOG.info("Goodbye.");
    }

    private static void initSchema(Connection conn) throws Exception {
        try (InputStream is = Main.class.getClassLoader().getResourceAsStream("schema.sql")) {
            if (is == null) {
                LOG.warn("schema.sql not found on classpath; skipping schema initialization.");
                return;
            }
            String fullSql = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            try (Statement stmt = conn.createStatement()) {
                for (String sqlStatement : fullSql.split(";")) {
                    String trimmed = sqlStatement.trim();
                    if (!trimmed.isEmpty()) {
                        stmt.execute(trimmed);
                    }
                }
            }
        }
        LOG.info("SQLite schema initialized successfully.");
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("+======================================+");
        System.out.println("|     Stock Matching Engine - Menu      |");
        System.out.println("+======================================+");
        System.out.println("|  1. Submit Order                     |");
        System.out.println("|  2. View Order Book                  |");
        System.out.println("|  3. Import Orders from CSV           |");
        System.out.println("|  4. Run Report (VWAP / Most Active)  |");
        System.out.println("|  5. Exit                             |");
        System.out.println("+======================================+");
        System.out.print("Select option: ");
    }

    private static void handleSubmitOrder(Scanner scanner) {
        System.out.println("\n--- Submit New Order ---");
        try {
            System.out.print("Enter Stock Symbol (e.g. AAPL, TSLA): ");
            String symbol = scanner.nextLine().trim().toUpperCase();
            if (symbol.isEmpty()) {
                System.out.println("Error: Symbol cannot be empty.");
                return;
            }

            System.out.print("Side (1 = BUY, 2 = SELL, or BUY/SELL): ");
            String sideInput = scanner.nextLine().trim().toUpperCase();
            OrderSide side;
            if ("1".equals(sideInput) || "BUY".equals(sideInput)) {
                side = OrderSide.BUY;
            } else if ("2".equals(sideInput) || "SELL".equals(sideInput)) {
                side = OrderSide.SELL;
            } else {
                System.out.println("Error: Invalid side. Enter 1 (BUY) or 2 (SELL).");
                return;
            }

            System.out.print("Order Type (1 = LIMIT, 2 = MARKET, or LIMIT/MARKET): ");
            String typeInput = scanner.nextLine().trim().toUpperCase();
            boolean isLimit;
            if ("1".equals(typeInput) || "LIMIT".equals(typeInput)) {
                isLimit = true;
            } else if ("2".equals(typeInput) || "MARKET".equals(typeInput)) {
                isLimit = false;
            } else {
                System.out.println("Error: Invalid order type.");
                return;
            }

            System.out.print("Quantity (positive integer): ");
            int quantity;
            try {
                quantity = Integer.parseInt(scanner.nextLine().trim());
                if (quantity <= 0) {
                    System.out.println("Error: Quantity must be greater than 0.");
                    return;
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Quantity must be a valid integer.");
                return;
            }

            if (isLimit) {
                System.out.print("Limit Price ($): ");
                double price;
                try {
                    price = Double.parseDouble(scanner.nextLine().trim());
                    if (price <= 0) {
                        System.out.println("Error: Price must be greater than 0.");
                        return;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Error: Price must be a valid number.");
                    return;
                }
                orderService.submitLimitOrder(symbol, side, quantity, price);
                System.out.printf("Successfully submitted LIMIT order: %s %d %s @ $%.2f%n", side, quantity, symbol, price);
            } else {
                orderService.submitMarketOrder(symbol, side, quantity);
                System.out.printf("Successfully submitted MARKET order: %s %d %s%n", side, quantity, symbol);
            }

            tradeDao.insertAuditLog("ORDER_SUBMITTED", symbol,
                    String.format("%s %s %d", side, isLimit ? "LIMIT" : "MARKET", quantity));

        } catch (InvalidOrderException e) {
            System.out.println("Order Rejected: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error submitting order: " + e.getMessage());
        }
    }

    private static void handleViewOrderBook(Scanner scanner) {
        System.out.println("\n--- View Order Book ---");
        System.out.print("Enter Stock Symbol (e.g. AAPL): ");
        String symbol = scanner.nextLine().trim().toUpperCase();
        if (symbol.isEmpty()) {
            System.out.println("Symbol cannot be empty.");
            return;
        }

        OrderBook book = engine.getOrderBook(symbol);
        if (book == null || book.size() == 0) {
            System.out.printf("No open resting orders in the book for %s.%n", symbol);
            return;
        }

        System.out.println();
        System.out.printf("================== ORDER BOOK: %s ==================%n", symbol);
        System.out.printf("Best Bid: %s | Best Ask: %s | Total Resting Orders: %d%n%n",
                book.getBestBid().isPresent() ? String.format("$%.2f", book.getBestBid().getAsDouble()) : "N/A",
                book.getBestAsk().isPresent() ? String.format("$%.2f", book.getBestAsk().getAsDouble()) : "N/A",
                book.size());

        System.out.println("--- ASKS (SELLERS) [Lowest ask first] ---");
        System.out.printf("%-12s | %-10s | %-8s%n", "Price", "Qty", "Orders");
        System.out.println("--------------------------------------");
        Map<Double, Queue<Order>> asks = book.getAsks();
        if (asks.isEmpty()) {
            System.out.println("  (No resting asks)");
        } else {
            for (Map.Entry<Double, Queue<Order>> entry : asks.entrySet()) {
                int levelQty = entry.getValue().stream().mapToInt(Order::getRemainingQuantity).sum();
                System.out.printf("$%-11.2f | %-10d | %-8d%n", entry.getKey(), levelQty, entry.getValue().size());
            }
        }

        System.out.println();
        System.out.println("--- BIDS (BUYERS) [Highest bid first] ---");
        System.out.printf("%-12s | %-10s | %-8s%n", "Price", "Qty", "Orders");
        System.out.println("--------------------------------------");
        Map<Double, Queue<Order>> bids = book.getBids();
        if (bids.isEmpty()) {
            System.out.println("  (No resting bids)");
        } else {
            for (Map.Entry<Double, Queue<Order>> entry : bids.entrySet()) {
                int levelQty = entry.getValue().stream().mapToInt(Order::getRemainingQuantity).sum();
                System.out.printf("$%-11.2f | %-10d | %-8d%n", entry.getKey(), levelQty, entry.getValue().size());
            }
        }
        System.out.println("====================================================");
    }

    private static void handleImportCSV(Scanner scanner) {
        System.out.println("\n--- Import Orders from CSV ---");
        System.out.print("Enter CSV file path (press Enter for default 'data/orders.csv'): ");
        String path = scanner.nextLine().trim();
        if (path.isEmpty()) {
            path = "data/orders.csv";
        }

        CsvOrderParser parser = new CsvOrderParser();
        try {
            CsvOrderParser.ParseResult result = parser.parse(path);
            System.out.printf("%nImport Result for '%s':%n", path);
            System.out.printf("  Valid orders parsed: %d%n", result.getValidOrders().size());
            System.out.printf("  Malformed lines:     %d%n%n", result.getErrors().size());

            if (!result.getErrors().isEmpty()) {
                System.out.println("Errors encountered:");
                for (String err : result.getErrors()) {
                    System.out.println("  [!] " + err);
                }
                System.out.println();
            }

            for (Order order : result.getValidOrders()) {
                orderDao.insert(order);
                engine.submitOrder(order);
            }

            // Allow background engine worker to process matches
            Thread.sleep(300);

            System.out.printf("Submitted %d orders into the matching engine.%n", result.getValidOrders().size());

        } catch (Exception e) {
            System.out.println("Failed to import CSV: " + e.getMessage());
        }
    }

    private static void handleRunReport(Scanner scanner) {
        System.out.println("\n--- Reports ---");
        System.out.println("1. Volume-Weighted Average Price (VWAP) for Symbol");
        System.out.println("2. Most Active Stocks by Volume");
        System.out.println("3. End-of-Day (EOD) Summary Report");
        System.out.println("4. Export EOD Summary Report to File");
        System.out.print("Choose report option (1 - 4): ");
        String repChoice = scanner.nextLine().trim();

        switch (repChoice) {
            case "1" -> {
                System.out.print("Enter Stock Symbol: ");
                String sym = scanner.nextLine().trim().toUpperCase();
                double vwap = reportService.calculateVWAP(sym);
                System.out.printf("VWAP for %s: $%.2f%n", sym, vwap);
            }
            case "2" -> {
                Map<String, Integer> active = reportService.getMostActiveSymbols();
                System.out.println("\n--- Most Active Stocks by Traded Volume ---");
                if (active.isEmpty()) {
                    System.out.println("No trades executed yet.");
                } else {
                    int rank = 1;
                    for (Map.Entry<String, Integer> entry : active.entrySet()) {
                        System.out.printf("#%d %-6s : %,d shares traded%n", rank++, entry.getKey(), entry.getValue());
                    }
                }
            }
            case "3" -> reportService.printEODReport();
            case "4" -> {
                System.out.print("Enter target file name (default 'eod_report.txt'): ");
                String file = scanner.nextLine().trim();
                if (file.isEmpty()) file = "eod_report.txt";
                try {
                    reportService.exportReport(file);
                    System.out.println("Report successfully exported to: " + file);
                } catch (Exception e) {
                    System.out.println("Failed to export report: " + e.getMessage());
                }
            }
            default -> System.out.println("Invalid report option.");
        }
    }
}
