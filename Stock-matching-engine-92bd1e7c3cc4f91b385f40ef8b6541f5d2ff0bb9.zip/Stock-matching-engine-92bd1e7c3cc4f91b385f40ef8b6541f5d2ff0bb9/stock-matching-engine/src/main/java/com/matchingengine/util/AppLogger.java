package com.matchingengine.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Lightweight logger wrapper for consistent console output.
 * Prefixes messages with timestamp and severity level.
 * Also supports file-based trade logging via {@link #logTradeToFile(String)}.
 */
public class AppLogger {

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private static final String TRADE_LOG_PATH = "logs/trades.log";

    private final String context;

    /**
     * Creates a logger tagged with the given context name (typically the class name).
     *
     * @param context the logging context
     */
    public AppLogger(String context) {
        this.context = context;
    }

    /**
     * Factory method — creates a logger for the given class.
     */
    public static AppLogger getLogger(Class<?> clazz) {
        return new AppLogger(clazz.getSimpleName());
    }

    public void info(String message) {
        log("INFO", message);
    }

    public void warn(String message) {
        log("WARN", message);
    }

    public void error(String message) {
        log("ERROR", message);
    }

    public void error(String message, Throwable throwable) {
        log("ERROR", message + " — " + throwable.getMessage());
    }

    public void debug(String message) {
        log("DEBUG", message);
    }

    private void log(String level, String message) {
        System.out.printf("[%s] [%-5s] [%s] %s%n",
                LocalDateTime.now().format(FMT), level, context, message);
    }

    /**
     * Appends a trade confirmation message to the rolling trade log file.
     * Creates the logs/ directory if it does not exist.
     *
     * @param message the trade confirmation message
     */
    public static synchronized void logTradeToFile(String message) {
        File logDir = new File("logs");
        if (!logDir.exists()) {
            logDir.mkdirs();
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TRADE_LOG_PATH, true))) {
            writer.write(String.format("[%s] %s%n", LocalDateTime.now().format(FMT), message));
        } catch (IOException e) {
            System.err.println("Failed to write to trade log file: " + e.getMessage());
        }
    }
}
