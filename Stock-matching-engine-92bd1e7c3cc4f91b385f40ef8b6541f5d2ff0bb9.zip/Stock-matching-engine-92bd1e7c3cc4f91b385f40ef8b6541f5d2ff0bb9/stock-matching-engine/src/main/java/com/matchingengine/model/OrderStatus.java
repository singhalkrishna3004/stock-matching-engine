package com.matchingengine.model;

/**
 * Lifecycle status of an order.
 */
public enum OrderStatus {
    NEW,
    PARTIALLY_FILLED,
    FILLED,
    CANCELLED
}
