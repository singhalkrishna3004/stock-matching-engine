package com.matchingengine.model;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Represents an executed trade — the result of matching a buy and sell order.
 */
public class Trade {

    private final String tradeId;
    private final String buyOrderId;
    private final String sellOrderId;
    private final String symbol;
    private final double price;
    private final int quantity;
    private final LocalDateTime executedAt;

    public Trade(String buyOrderId, String sellOrderId, String symbol,
                 double price, int quantity) {
        this(UUID.randomUUID().toString(), buyOrderId, sellOrderId, symbol, price, quantity, LocalDateTime.now());
    }

    public Trade(String tradeId, String buyOrderId, String sellOrderId, String symbol,
                 double price, int quantity, LocalDateTime executedAt) {
        this.tradeId = tradeId != null ? tradeId : UUID.randomUUID().toString();
        this.buyOrderId = buyOrderId;
        this.sellOrderId = sellOrderId;
        this.symbol = symbol;
        this.price = price;
        this.quantity = quantity;
        this.executedAt = executedAt != null ? executedAt : LocalDateTime.now();
    }

    // ---- Getters ----

    public String getTradeId()      { return tradeId; }
    public String getBuyOrderId()   { return buyOrderId; }
    public String getSellOrderId()  { return sellOrderId; }
    public String getSymbol()       { return symbol; }
    public double getPrice()        { return price; }
    public int getQuantity()        { return quantity; }
    public LocalDateTime getExecutedAt() { return executedAt; }

    @Override
    public String toString() {
        String idPrefix = tradeId.length() >= 8 ? tradeId.substring(0, 8) : tradeId;
        String buyPrefix = buyOrderId.length() >= 8 ? buyOrderId.substring(0, 8) : buyOrderId;
        String sellPrefix = sellOrderId.length() >= 8 ? sellOrderId.substring(0, 8) : sellOrderId;
        return String.format("Trade[%s] %s %d @ %.2f (buy=%s, sell=%s)",
                idPrefix, symbol, quantity, price,
                buyPrefix, sellPrefix);
    }
}
