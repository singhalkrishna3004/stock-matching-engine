package com.matchingengine.util;

import com.matchingengine.model.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Parses a CSV file of orders into {@link Order} objects.
 * Expected CSV format: orderId,symbol,side,type,price,quantity
 *
 * <p>Malformed rows are logged and skipped rather than aborting the entire import.
 */
public class CsvOrderParser {

    /**
     * Parses the given CSV file and returns a list of valid orders.
     * Malformed rows are collected in the returned {@link ParseResult}.
     *
     * @param filePath path to the CSV file
     * @return a ParseResult containing valid orders and error details
     */
    public ParseResult parse(String filePath) {
        List<Order> validOrders = new ArrayList<>();
        List<String> errors = new ArrayList<>();

        File file = new File(filePath);
        if (!file.exists() || !file.isFile()) {
            throw new IllegalArgumentException("File not found: " + filePath);
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line = reader.readLine(); // Header line
            if (line == null) {
                return new ParseResult(validOrders, errors);
            }

            int lineNum = 1;
            while ((line = reader.readLine()) != null) {
                lineNum++;
                String trimmed = line.trim();
                if (trimmed.isEmpty()) {
                    continue;
                }

                // Split keeping empty trailing tokens
                String[] tokens = trimmed.split(",", -1);
                if (tokens.length < 6) {
                    errors.add(String.format("Line %d: Insufficient columns (expected 6, found %d) -> '%s'", lineNum, tokens.length, trimmed));
                    continue;
                }

                String orderId = tokens[0].trim();
                String symbol = tokens[1].trim();
                String sideStr = tokens[2].trim();
                String typeStr = tokens[3].trim();
                String priceStr = tokens[4].trim();
                String qtyStr = tokens[5].trim();

                if (orderId.isEmpty() || symbol.isEmpty()) {
                    errors.add(String.format("Line %d: Missing orderId or symbol -> '%s'", lineNum, trimmed));
                    continue;
                }

                OrderSide side;
                try {
                    side = OrderSide.valueOf(sideStr.toUpperCase());
                } catch (IllegalArgumentException e) {
                    errors.add(String.format("Line %d: Invalid side '%s' -> '%s'", lineNum, sideStr, trimmed));
                    continue;
                }

                int quantity;
                try {
                    quantity = Integer.parseInt(qtyStr);
                    if (quantity <= 0) {
                        errors.add(String.format("Line %d: Quantity must be positive (%d) -> '%s'", lineNum, quantity, trimmed));
                        continue;
                    }
                } catch (NumberFormatException e) {
                    errors.add(String.format("Line %d: Invalid quantity '%s' -> '%s'", lineNum, qtyStr, trimmed));
                    continue;
                }

                if ("LIMIT".equalsIgnoreCase(typeStr)) {
                    double price;
                    try {
                        price = Double.parseDouble(priceStr);
                        if (price <= 0) {
                            errors.add(String.format("Line %d: Limit price must be positive (%s) -> '%s'", lineNum, priceStr, trimmed));
                            continue;
                        }
                    } catch (NumberFormatException e) {
                        errors.add(String.format("Line %d: Invalid price for limit order '%s' -> '%s'", lineNum, priceStr, trimmed));
                        continue;
                    }
                    validOrders.add(new LimitOrder(orderId, symbol, side, quantity, price, 0, OrderStatus.NEW, null));
                } else if ("MARKET".equalsIgnoreCase(typeStr)) {
                    validOrders.add(new MarketOrder(orderId, symbol, side, quantity, 0, OrderStatus.NEW, null));
                } else {
                    errors.add(String.format("Line %d: Unknown order type '%s' -> '%s'", lineNum, typeStr, trimmed));
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Error reading CSV file: " + filePath, e);
        }

        return new ParseResult(validOrders, errors);
    }

    // ----------------------------------------------------------------
    //  Result container
    // ----------------------------------------------------------------

    /**
     * Holds the results of a CSV parse — valid orders and per-row errors.
     */
    public static class ParseResult {
        private final List<Order> validOrders;
        private final List<String> errors;

        public ParseResult(List<Order> validOrders, List<String> errors) {
            this.validOrders = validOrders;
            this.errors = errors;
        }

        public List<Order> getValidOrders() { return validOrders; }
        public List<String> getErrors()     { return errors; }

        public int totalRows()  { return validOrders.size() + errors.size(); }
        public int errorCount() { return errors.size(); }
    }
}
