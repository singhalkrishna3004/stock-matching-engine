package com.matchingengine.exception;

/**
 * Thrown when an order fails validation — invalid price, zero/negative quantity, etc.
 */
public class InvalidOrderException extends Exception {

    public InvalidOrderException(String message) {
        super(message);
    }

    public InvalidOrderException(String message, Throwable cause) {
        super(message, cause);
    }
}
