package com.matchingengine.service;

import com.matchingengine.dao.TradeDao;
import com.matchingengine.model.Trade;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Reporting service — VWAP, most-active symbols, and EOD summary exports.
 * All analytics should leverage the Streams API.
 */
public class ReportService {

    private final TradeDao tradeDao;

    public ReportService(TradeDao tradeDao) {
        this.tradeDao = tradeDao;
    }

    // ----------------------------------------------------------------
    //  Analytics
    // ----------------------------------------------------------------

    /**
     * Calculates the Volume-Weighted Average Price for a given symbol.
     *
     * <p>VWAP = Σ(price × quantity) / Σ(quantity)
     *
     * @param symbol the stock symbol
     * @return the VWAP value
     */
    public double calculateVWAP(String symbol) {
        if (symbol == null || tradeDao == null) {
            return 0.0;
        }
        List<Trade> trades = tradeDao.findBySymbol(symbol.trim().toUpperCase());
        double totalNotional = trades.stream().mapToDouble(t -> t.getPrice() * t.getQuantity()).sum();
        int totalVolume = trades.stream().mapToInt(Trade::getQuantity).sum();
        return totalVolume == 0 ? 0.0 : totalNotional / totalVolume;
    }

    /**
     * Returns symbols ranked by total traded volume (descending).
     *
     * @return map of symbol → total quantity traded
     */
    public Map<String, Integer> getMostActiveSymbols() {
        if (tradeDao == null) {
            return Collections.emptyMap();
        }
        List<Trade> trades = tradeDao.findAll();
        Map<String, Integer> volumeBySymbol = trades.stream()
                .collect(Collectors.groupingBy(Trade::getSymbol, Collectors.summingInt(Trade::getQuantity)));

        return volumeBySymbol.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (a, b) -> a,
                        LinkedHashMap::new
                ));
    }

    /**
     * Generates and prints an end-of-day summary report to stdout.
     * Includes: total trades, total volume, per-symbol VWAP, most-active ranking.
     */
    public void printEODReport() {
        System.out.println(buildReportString());
    }

    /**
     * Exports the EOD report to a file.
     *
     * @param filePath path to the output file
     */
    public void exportReport(String filePath) {
        String report = buildReportString();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, StandardCharsets.UTF_8))) {
            writer.write(report);
        } catch (IOException e) {
            throw new RuntimeException("Failed to export report to " + filePath, e);
        }
    }

    public String buildReportString() {
        StringBuilder sb = new StringBuilder();
        sb.append("====================================================\n");
        sb.append("         STOCK MATCHING ENGINE - EOD REPORT         \n");
        sb.append("====================================================\n");

        if (tradeDao == null) {
            sb.append("No trade data available.\n");
            return sb.toString();
        }

        List<Trade> allTrades = tradeDao.findAll();
        int totalVolume = allTrades.stream().mapToInt(Trade::getQuantity).sum();
        double totalNotional = allTrades.stream().mapToDouble(t -> t.getPrice() * t.getQuantity()).sum();

        sb.append(String.format("Total Trades: %d%n", allTrades.size()));
        sb.append(String.format("Total Volume: %d shares%n", totalVolume));
        sb.append(String.format("Total Value:  $%.2f%n%n", totalNotional));

        sb.append("--- Most Active Symbols ---\n");
        Map<String, Integer> active = getMostActiveSymbols();
        if (active.isEmpty()) {
            sb.append("  (No trades recorded)\n");
        } else {
            int rank = 1;
            for (Map.Entry<String, Integer> entry : active.entrySet()) {
                double vwap = calculateVWAP(entry.getKey());
                sb.append(String.format("  #%d %-6s | Volume: %,8d shares | VWAP: $%,.2f%n",
                        rank++, entry.getKey(), entry.getValue(), vwap));
            }
        }
        sb.append("====================================================\n");
        return sb.toString();
    }
}
