package com.matchingengine.model;

/**
 * Represents the side of an order — buy or sell.
 */
public enum OrderSide {
    BUY,
    SELL
}
