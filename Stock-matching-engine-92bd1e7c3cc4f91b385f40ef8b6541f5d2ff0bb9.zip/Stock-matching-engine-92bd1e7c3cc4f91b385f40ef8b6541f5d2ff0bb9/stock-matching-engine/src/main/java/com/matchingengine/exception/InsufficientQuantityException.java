package com.matchingengine.exception;

/**
 * Thrown when an operation requires more quantity than is available on an order.
 */
public class InsufficientQuantityException extends Exception {

    public InsufficientQuantityException(String message) {
        super(message);
    }

    public InsufficientQuantityException(String message, Throwable cause) {
        super(message, cause);
    }
}
