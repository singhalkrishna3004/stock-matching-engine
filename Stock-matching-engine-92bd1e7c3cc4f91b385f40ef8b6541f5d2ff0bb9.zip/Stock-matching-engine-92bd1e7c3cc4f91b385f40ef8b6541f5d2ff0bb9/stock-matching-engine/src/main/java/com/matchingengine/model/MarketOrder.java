package com.matchingengine.model;

import java.time.LocalDateTime;

/**
 * A market order — executes at the best available price.
 * Has no price constraint; price is determined at match time.
 */
public class MarketOrder extends Order {

    public MarketOrder(String symbol, OrderSide side, int quantity) {
        super(symbol, side, quantity);
    }

    public MarketOrder(String orderId, String symbol, OrderSide side, int quantity,
                       int filledQuantity, OrderStatus status, LocalDateTime createdAt) {
        super(orderId, symbol, side, quantity, filledQuantity, status, createdAt);
    }

    @Override
    public boolean isLimitOrder() {
        return false;
    }

    /**
     * Market orders have no price; returns 0.0 by convention.
     */
    @Override
    public double getPrice() {
        return 0.0;
    }
}
