package com.matchingengine.engine;

import com.matchingengine.book.OrderBook;
import com.matchingengine.dao.OrderDao;
import com.matchingengine.dao.TradeDao;
import com.matchingengine.exception.InvalidOrderException;
import com.matchingengine.model.Order;
import com.matchingengine.model.Trade;
import com.matchingengine.util.AppLogger;

import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * The matching engine — runs on a dedicated thread, consuming orders from a
 * {@link BlockingQueue} and dispatching them to per-symbol {@link OrderBook}s.
 *
 * <p>Multiple trader threads submit orders via {@link #submitOrder(Order)}.
 * The engine's internal thread drains the queue and processes matches
 * single-threadedly (no lock contention on the order book).
 */
public class MatchingEngine implements Runnable {

    private static final AppLogger LOG = AppLogger.getLogger(MatchingEngine.class);

    private final BlockingQueue<Order> orderQueue;
    private final Map<String, OrderBook> orderBooks;
    private volatile boolean running;
    private Thread engineThread;

    private volatile TradeDao tradeDao;
    private volatile OrderDao orderDao;

    public MatchingEngine() {
        this(null, null);
    }

    public MatchingEngine(TradeDao tradeDao, OrderDao orderDao) {
        this.orderQueue = new LinkedBlockingQueue<>();
        this.orderBooks = new ConcurrentHashMap<>();
        this.running = false;
        this.tradeDao = tradeDao;
        this.orderDao = orderDao;
    }

    public void setTradeDao(TradeDao tradeDao) {
        this.tradeDao = tradeDao;
    }

    public void setOrderDao(OrderDao orderDao) {
        this.orderDao = orderDao;
    }

    // ----------------------------------------------------------------
    //  Submit an order (called by trader threads)
    // ----------------------------------------------------------------

    /**
     * Thread-safe order submission. Adds the order to the internal queue
     * for asynchronous processing by the engine thread.
     *
     * @param order the order to submit
     */
    public void submitOrder(Order order) {
        if (order == null) {
            throw new RuntimeException(new InvalidOrderException("Order cannot be null"));
        }
        if (order.getSymbol() == null || order.getSymbol().trim().isEmpty()) {
            throw new RuntimeException(new InvalidOrderException("Symbol cannot be empty"));
        }
        if (order.getQuantity() <= 0) {
            throw new RuntimeException(new InvalidOrderException("Quantity must be positive"));
        }
        if (order.getSide() == null) {
            throw new RuntimeException(new InvalidOrderException("Order side cannot be null"));
        }
        if (order.isLimitOrder() && order.getPrice() <= 0) {
            throw new RuntimeException(new InvalidOrderException("Limit order price must be positive"));
        }

        orderQueue.offer(order);
    }

    // ----------------------------------------------------------------
    //  Engine loop (runs on its own thread)
    // ----------------------------------------------------------------

    /**
     * Main event loop — takes orders from the queue and matches them.
     * This method blocks on the queue and should be run in a dedicated thread.
     */
    @Override
    public void run() {
        LOG.info("Matching Engine worker loop started.");

        try {
            while (running || !orderQueue.isEmpty()) {
                try {
                    Order order = orderQueue.poll(100, TimeUnit.MILLISECONDS);
                    if (order == null) {
                        continue;
                    }

                    String sym = order.getSymbol().toUpperCase().trim();
                    OrderBook book = orderBooks.computeIfAbsent(sym, OrderBook::new);
                    List<Trade> trades = book.match(order);

                    // Update incoming order in DB if orderDao is attached
                    if (orderDao != null) {
                        try {
                            orderDao.update(order);
                        } catch (Exception e) {
                            LOG.error("Failed to update order status in DB: " + order.getOrderId(), e);
                        }
                    }

                    // Persist trades
                    if (tradeDao != null) {
                        for (Trade trade : trades) {
                            try {
                                tradeDao.insert(trade);
                                tradeDao.insertAuditLog("ORDER_MATCHED", trade.getTradeId(),
                                        String.format("Matched %d %s @ %.2f (buy=%s, sell=%s)",
                                                trade.getQuantity(), trade.getSymbol(), trade.getPrice(),
                                                trade.getBuyOrderId(), trade.getSellOrderId()));

                                // Trade confirmation — console + file log
                                String confirmation = String.format(
                                        "Trade executed: %d %s @ $%.2f (BUY order %s x SELL order %s)",
                                        trade.getQuantity(), trade.getSymbol(), trade.getPrice(),
                                        trade.getBuyOrderId(), trade.getSellOrderId());
                                System.out.println(confirmation);
                                AppLogger.logTradeToFile(confirmation);

                                // Update the opposite order status in orderDao as well
                                if (orderDao != null) {
                                    String oppositeId = order.getOrderId().equals(trade.getBuyOrderId())
                                            ? trade.getSellOrderId() : trade.getBuyOrderId();
                                    orderDao.findById(oppositeId).ifPresent(orderDao::update);
                                }
                            } catch (Exception e) {
                                LOG.error("Failed to persist trade: " + trade.getTradeId(), e);
                            }
                        }
                    }

                } catch (InterruptedException e) {
                    if (!running && orderQueue.isEmpty()) {
                        break;
                    }
                }
            }
        } finally {
            running = false;
            LOG.info("Matching Engine worker loop terminated.");
        }
    }

    // ----------------------------------------------------------------
    //  Lifecycle
    // ----------------------------------------------------------------

    /**
     * Starts the engine on a new daemon thread.
     */
    public synchronized void start() {
        if (running) {
            return;
        }
        running = true;
        engineThread = new Thread(this, "MatchingEngine-Worker");
        engineThread.setDaemon(true);
        engineThread.start();
    }

    /**
     * Signals the engine to stop after draining remaining orders.
     */
    public synchronized void stop() {
        running = false;
        if (engineThread != null) {
            engineThread.interrupt();
            try {
                engineThread.join(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            engineThread = null;
        }
    }

    // ----------------------------------------------------------------
    //  Queries
    // ----------------------------------------------------------------

    /**
     * Returns the order book for the given symbol, or null if none exists.
     */
    public OrderBook getOrderBook(String symbol) {
        if (symbol == null) return null;
        return orderBooks.get(symbol.toUpperCase().trim());
    }

    /**
     * Returns all active order books.
     */
    public Map<String, OrderBook> getAllOrderBooks() {
        return Map.copyOf(orderBooks);
    }

    /**
     * Returns the number of orders waiting in the queue.
     */
    public int getPendingOrderCount() {
        return orderQueue.size();
    }

    public boolean isRunning() {
        return running;
    }
}
