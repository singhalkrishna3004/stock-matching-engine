package com.matchingengine.exception;

/**
 * Thrown when a requested order cannot be found by its ID.
 */
public class OrderNotFoundException extends Exception {

    public OrderNotFoundException(String message) {
        super(message);
    }

    public OrderNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
