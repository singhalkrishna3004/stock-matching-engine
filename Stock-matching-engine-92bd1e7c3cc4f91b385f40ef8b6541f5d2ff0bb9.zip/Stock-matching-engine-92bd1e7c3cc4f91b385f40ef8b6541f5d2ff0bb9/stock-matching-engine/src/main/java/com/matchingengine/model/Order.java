package com.matchingengine.model;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Abstract base class for all order types.
 * Concrete subclasses: {@link MarketOrder}, {@link LimitOrder}.
 */
public abstract class Order {

    private final String orderId;
    private final String symbol;
    private final OrderSide side;
    private int quantity;
    private int filledQuantity;
    private OrderStatus status;
    private final LocalDateTime createdAt;

    protected Order(String symbol, OrderSide side, int quantity) {
        this(UUID.randomUUID().toString(), symbol, side, quantity, 0, OrderStatus.NEW, LocalDateTime.now());
    }

    protected Order(String orderId, String symbol, OrderSide side, int quantity,
                    int filledQuantity, OrderStatus status, LocalDateTime createdAt) {
        this.orderId = orderId != null ? orderId : UUID.randomUUID().toString();
        this.symbol = symbol;
        this.side = side;
        this.quantity = quantity;
        this.filledQuantity = filledQuantity;
        this.status = status != null ? status : OrderStatus.NEW;
        this.createdAt = createdAt != null ? createdAt : LocalDateTime.now();
    }

    // ---- Getters ----

    public String getOrderId()        { return orderId; }
    public String getSymbol()         { return symbol; }
    public OrderSide getSide()        { return side; }
    public int getQuantity()          { return quantity; }
    public int getFilledQuantity()    { return filledQuantity; }
    public OrderStatus getStatus()    { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    // ---- Setters for mutable fields ----

    public void setQuantity(int quantity)             { this.quantity = quantity; }
    public void setFilledQuantity(int filledQuantity) { this.filledQuantity = filledQuantity; }
    public void setStatus(OrderStatus status)         { this.status = status; }

    /**
     * Returns the remaining unfilled quantity.
     */
    public int getRemainingQuantity() {
        return quantity - filledQuantity;
    }

    /**
     * Returns true if this is a limit order with a specific price.
     */
    public abstract boolean isLimitOrder();

    /**
     * Returns the limit price, or 0.0 for market orders.
     */
    public abstract double getPrice();

    @Override
    public String toString() {
        String idPrefix = orderId.length() >= 8 ? orderId.substring(0, 8) : orderId;
        return String.format("[%s] %s %s %d @ %s (filled=%d, status=%s)",
                idPrefix, side, symbol, quantity,
                isLimitOrder() ? String.format("%.2f", getPrice()) : "MKT",
                filledQuantity, status);
    }
}
