package com.matchingengine.model;

import java.time.LocalDateTime;

/**
 * A limit order — specifies the maximum buy price or minimum sell price.
 */
public class LimitOrder extends Order {

    private final double price;

    public LimitOrder(String symbol, OrderSide side, int quantity, double price) {
        super(symbol, side, quantity);
        this.price = price;
    }

    public LimitOrder(String orderId, String symbol, OrderSide side, int quantity,
                      double price, int filledQuantity, OrderStatus status, LocalDateTime createdAt) {
        super(orderId, symbol, side, quantity, filledQuantity, status, createdAt);
        this.price = price;
    }

    @Override
    public boolean isLimitOrder() {
        return true;
    }

    @Override
    public double getPrice() {
        return price;
    }
}
